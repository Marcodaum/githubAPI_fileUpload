# Standup Board

Create and organize standup meetings.

## Nomenclature

### Board

A board represents an office. It includes scheduling and notification details.

### Board Item

A board item is the representation of a topic or event. 

It can be displayed on a single day or over a period of time. 

It can also be displayed to every other board, also known as global item.

### Standup

A standup is a collection of board items that are meant to be displayed on a specific day for a specific office.

It includes both global and office-specific board items.

## Where can you access it
- [Acceptance](https://start-acceptance.vwapps.run)
- Production is TODO

## Contributing Guidelines
- For styling, we use the [GroupUI components](https://volkswagen.frontify.com/d/rzB71PwpjXgt/documentation#/components/overview) as much as possible (the designs should already be respecting GroupUI), and create styled components where needed. No custom CSS files.
- Try to follow a TDD approach as much as possible:
  - The frontend contains tests for each page, where user behaviour is tested (so sort of integration tests).
  - The api contains integration tests that test each route/handler.
- Add e2e tests where appropriate. For now, the e2e tests only run locally and not on the pipeline due to technical constraints (to be tackled in the future).
- No need for pull requests - just push code in the main branch and it will trigger a CodePipeline that will build/test/deploy the whole application.

## Running Locally

### Install dependencies
1. Run `npm i` once in the frontend folder, e2e and infrastructure folder to install the dependencies.

### Docker
1. Run `make docker-up` or `make docker-build` to start all the containers needed to run the project.
2. To build or start an individual container, run `docker compose up -d <name-of-the-service>` (check docker-compose for the service name).

### Frontend
1. Run `npm start` and access it on http://localhost:3030.
2. Run `npm test` in the frontend to run tests.

### Backend
1. Running in docker on http://localhost:3000
2. Run `cargo test` in the backend to run tests.

### E2E
1. Run `npm test` to run the testcafe suite.


### Accessing local DynamoDB
Once you have the docker containers running, you can access the values inside docker the DynamoDB:

1. Go to the migration container cli on docker dashboard
2. Run `aws configure` with `x` for both Access keys and `local` for the region name (you can leave the output format as the default).
3. Run any command you want with `--endpoint=http://dynamodb-local:8000`.

If you want to scan the whole table for example, you can do `aws dynamodb scan --table-name StandupBoard --endpoint=http://dynamodb-local:8000`.

### Infrastructure (NOTE: this is only needed if you need to manually deploy a stack)
1. Run `vws2` and `vws2-artifacts` (see https://github.com/vw-sre/vws2-credentials-loader) to load credentials for downloading vws-cdk.
