import React from 'react';
import { createRoot } from 'react-dom/client';
import { applyPolyfills, defineCustomElements } from '@group-ui/group-ui/dist/loader';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.scss';
import '@group-ui/group-ui/dist/group-ui/assets/themes/vwag/vwag.css';

applyPolyfills().then(() => defineCustomElements());

const container = document.getElementById('app');
if (!container) throw new Error('Failed to find the root element');

createRoot(container).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
);
