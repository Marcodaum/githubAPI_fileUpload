import apiFetch from './api-fetch';

describe('api fetch function', () => {
  beforeEach(() => {
    window.fetch = jest.fn().mockImplementation();
  });

  it('makes a server request', async () => {
    jest.mocked(window.fetch).mockResolvedValue(new Response(undefined, { status: 200 }));

    const response = await apiFetch('fake-url');
    expect(response.status).toEqual(200);
    expect(window.fetch).toHaveBeenCalledTimes(1);
    expect(window.fetch).toHaveBeenCalledWith('http://localhost:9999/fake-url', {
      method: 'GET',
      body: undefined,
      headers: { 'Content-Type': 'application/json' },
    });
  });

  it('makes a request with the method and body', async () => {
    jest.mocked(window.fetch).mockResolvedValue(new Response(undefined, { status: 200 }));

    const response = await apiFetch('fake-url', { method: 'POST', body: 'my-body' });
    expect(response.status).toEqual(200);
    expect(window.fetch).toHaveBeenCalledWith('http://localhost:9999/fake-url', {
      method: 'POST',
      body: 'my-body',
      headers: { 'Content-Type': 'application/json' },
    });
  });

  it('throws an error with the error from the body', async () => {
    jest.mocked(window.fetch).mockResolvedValue(
      new Response(JSON.stringify({ error: 'I should fail' }), { status: 500 }),
    );

    const request = apiFetch('fake-url');
    await expect(request).rejects.toThrow('I should fail');
    await expect(request).rejects.toBeInstanceOf(Error);
  });

  it('throws a default error when the error body is empty', async () => {
    jest.mocked(window.fetch).mockResolvedValue(new Response(undefined, { status: 500 }));

    const request = apiFetch('fake-url');
    await expect(request).rejects.toThrow('Server returned an error with status 500');
    await expect(request).rejects.toBeInstanceOf(Error);
  });
});
