import { format } from 'date-fns';
import { utcToZonedTime, zonedTimeToUtc } from 'date-fns-tz';

const today = (): string => format(new Date(), 'yyyy-MM-dd');

const getLocalTimezone = (): string => Intl.DateTimeFormat().resolvedOptions().timeZone;

const toLocalTime = (fromTime: string, fromTimezone: string) : string => {
  const utcTime = zonedTimeToUtc(`${today()} ${fromTime}:00.000`, fromTimezone);
  const localTime = utcToZonedTime(utcTime, getLocalTimezone());
  return format(localTime, 'HH:mm');
};

export { today, getLocalTimezone, toLocalTime };
