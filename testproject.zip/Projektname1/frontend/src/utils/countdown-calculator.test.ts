import { getCountdownForTime, parseStartTimeAsMilliseconds } from './countdown-calculator';

describe('countdown-calculator', () => {
  describe('parseTimeForToday', () => {
    it('returns the timestamp of given format hh:mm', () => {
      const givenTimeString = '12:34';
      const now = new Date();
      const expectedTimestamp = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        12,
        34,
        0,
        0,
      )
        .getTime();

      expect(parseStartTimeAsMilliseconds(givenTimeString)).toEqual(expectedTimestamp);
    });

    it.each([
      '-1:00',
      '24:00',
      '0:60',
      '0:-01',
    ])('throws exception for incompliant timeString %s', (givenTimeString: string) => {
      expect(() => parseStartTimeAsMilliseconds(givenTimeString)).toThrow();
    });
  });

  describe('getCountdown', () => {
    it('returns rounded remaining seconds to given time', () => {
      const now = new Date();
      jest.useFakeTimers();
      jest.setSystemTime(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 59, 0, 0));
      const givenTimeString = '09:10';

      expect(getCountdownForTime(givenTimeString)).toEqual(11 * 60);
    });

    it('returns 0 seconds if given time has been already reached', () => {
      const now = new Date();
      jest.useFakeTimers();
      jest.setSystemTime(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 10, 1, 0));
      const givenTimeString = '09:10';

      expect(getCountdownForTime(givenTimeString)).toEqual(0);
    });
  });
});
