export interface RequestParams {
  method?: string;
  body?: any;
  headers?: any;
}

const apiFetch = (url: string, params?: RequestParams) => (
  fetch(`${process.env.API_URL}/${url}`, {
    method: params?.method || 'GET',
    body: params?.body,
    headers: params?.headers || { 'Content-Type': 'application/json' },
  }).then(async (resp) => {
    if (!resp.ok) {
      let err;
      try {
        err = (await resp.json()).error;
      } catch (e) {
        err = `Server returned an error with status ${resp.status}`;
      }
      throw new Error(err);
    }
    return resp;
  })
);

export default apiFetch;
