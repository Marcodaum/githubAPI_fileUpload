const isTimeStringInvalid = (hour: number, minute: number): boolean => (
  hour < 0
    || hour > 23
    || minute > 59
    || minute < 0
);

const extractHourAndMinuteFromTimeString = (timeString: string): number[] => timeString
  .split(':')
  .map((time) => Number.parseInt(time, 10));

export const parseStartTimeAsMilliseconds = (hourAndMinuteTimeString: string): number => {
  const now = new Date();
  const [startHour, startMinutes] = extractHourAndMinuteFromTimeString(hourAndMinuteTimeString);

  if (isTimeStringInvalid(startHour, startMinutes)) throw new Error(`given timeString is invalid: ${hourAndMinuteTimeString}`);

  return new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    startHour,
    startMinutes,
    0,
    0,
  )
    .getTime();
};

export const getCountdownForTime = (hourAndMinute: string): number => {
  const remainingSecondsToStart = Math.round(
    (parseStartTimeAsMilliseconds(hourAndMinute) - Date.now()) / 1000,
  );
  return remainingSecondsToStart > 0 ? remainingSecondsToStart : 0;
};
