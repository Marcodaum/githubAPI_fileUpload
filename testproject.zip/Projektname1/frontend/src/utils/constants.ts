const dateOptions = {
  TODAY: 0,
  TOMORROW: 1,
  OTHER: 3,
};

const categoryOptions = {
  global: {
    id: 'global',
    name: 'Global',
    description: 'Items that are shared in all office standups',
  },
  faces: {
    id: '1',
    name: 'New Faces',
    description: 'Announce a new team member/visitor, or a new tasty meal, or exciting place to visit',
  },
  helps: {
    id: '2',
    name: 'Helps and Offers',
    description: 'For when you need help with something or in case you want to offer something (like cake!)',
  },
  interesting: {
    id: '3',
    name: 'Interesting',
    description: 'Share something that you think people in the office could be interested in',
  },
  events: {
    id: '4',
    name: 'Events',
    description: 'Announce an event that you think people in your lab could be interested in',
  },
};

export { dateOptions, categoryOptions };
