import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from 'react-query';
import Cookies from 'js-cookie';
import { Route, Routes } from 'react-router-dom';
import AppLayout from './components/layout/app-layout';
import Boards from './pages/boards';
import BoardIdLayout from './components/layout/board-id-layout';
import Board from './pages/board';
import AddItem from './pages/add-item';
import EditItem from './pages/edit-item';
import PresentationLayout from './components/layout/presentation-layout';
import PresentCountdown from './pages/present/countdown';
import PresentCategory from './pages/present/category';
import AddBoard from './pages/add-board';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      useErrorBoundary: true,
      retry: 1,
    },
  },
});

const App = () => {
  const [boardId, setBoardId] = useState(Cookies.get('board'));

  const changeBoard = (id: string) => {
    Cookies.remove('board');
    Cookies.set('board', id, { expires: 90 });
    setBoardId(id);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route path="add-board" element={<AddBoard />} />
          <Route path="boards" element={<Boards onSelect={changeBoard} />} />
          <Route path="" element={<BoardIdLayout boardId={boardId} />}>
            <Route index element={<Board />} />
            <Route path="add-item" element={<AddItem />} />
            <Route path="edit-item/:itemId" element={<EditItem />} />
            <Route path="present" element={<PresentationLayout />}>
              <Route index element={<PresentCountdown />} />
              <Route path=":categoryId" element={<PresentCategory />} />
            </Route>
          </Route>
        </Route>
      </Routes>
    </QueryClientProvider>
  );
};

export default App;
