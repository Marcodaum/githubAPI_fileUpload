import React from 'react';
import {
  GroupuiButton, GroupuiCard, GroupuiHeadline,
} from '@group-ui/group-ui-react';
import { useForm } from 'react-hook-form';
import { useMutation } from 'react-query';
import { useNavigate } from 'react-router-dom';
import apiFetch from '../../utils/api-fetch';
import Container from '../../components/styled/container';
import Breadcrumb from '../../components/layout/breadcrumb';
import useNotificationContext from '../../hooks/contexts/use-notification-context';
import NotificationType from '../../models/notification-type';
import TextInput from '../../components/form/text-input';
import { categoryOptions } from '../../utils/constants';
import BoardCategories from '../../components/pages.add-edit-board/board-categories';
import { Grey1000Headline, Grey700Text } from '../../components/styled/grey-text';

interface CategoryFields {
  id: string,
  name: string,
  description: string,
}

interface AddBoardFields {
  name: string,
  startTime: string,
  timezone: string,
  emailFrom: string,
  emailTo: string[],
  slackWebhook: string,
  categories: CategoryFields[],
}

const AddBoard = () => {
  const navigate = useNavigate();
  const { setNotification } = useNotificationContext();

  const defaultValues: AddBoardFields = {
    name: '',
    startTime: '09:00',
    timezone: 'Europe/Berlin',
    emailFrom: '',
    emailTo: [],
    slackWebhook: '',
    categories: [
      categoryOptions.faces,
      categoryOptions.helps,
      categoryOptions.interesting,
      categoryOptions.events,
    ],
  };
  const { control, handleSubmit } = useForm({ defaultValues });

  const addBoard = useMutation<Response, Error, AddBoardFields, any>(
    (data: AddBoardFields) => apiFetch('boards', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    {
      onSuccess: () => {
        setNotification(NotificationType.Success, 'Board successfully added!');
        navigate('/boards');
      },
      onError: () => setNotification(NotificationType.Error, 'Oops! There has been error trying to add the board.'),
    },
  );

  const onSubmit = handleSubmit((data) => addBoard.mutate(data));

  return (
    <>
      <Breadcrumb url="/boards" label="View all boards" />
      <GroupuiHeadline heading="h2">Add Board</GroupuiHeadline>
      <form onSubmit={onSubmit}>
        <Container marginTop={7}>
          <Container marginBottom={7}>
            <Grey1000Headline heading="h4">Board details</Grey1000Headline>
            <Grey700Text size="body-2">Complete the details for the office&rsquo;s standup</Grey700Text>
          </Container>
          <TextInput
            label="Name"
            control={control}
            name="name"
            placeholder="Board or office name"
            required
          />
          <TextInput
            label="Standup time"
            control={control}
            name="startTime"
            placeholder="Start time of standup e.g. 09:00"
            required
          />
          <TextInput
            label="Timezone"
            control={control}
            name="timezone"
            placeholder="Timezone of the office e.g. Europe/Berlin"
            required
          />
        </Container>
        <Container marginTop={10}>
          <Container marginBottom={7}>
            <Grey1000Headline heading="h4">Standup categories</Grey1000Headline>
            <Grey700Text size="body-2">The office&rsquo;s standup presentation categories</Grey700Text>
          </Container>
          <BoardCategories control={control} />
        </Container>
        <Container marginTop={8}>
          <GroupuiButton role="button" type="submit" disabled={addBoard.isLoading} icon="save-24">Save</GroupuiButton>
        </Container>
      </form>
    </>
  );
};

export default AddBoard;
