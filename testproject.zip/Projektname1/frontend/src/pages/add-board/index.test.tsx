import React from 'react';
import { fireEvent, waitFor, within } from '@testing-library/react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { Route, Routes } from 'react-router-dom';
import userEvent from '@testing-library/user-event';
import { groupuiChange, render, screen } from '../../test/utils';
import AddBoard from './index';
import * as useNotificationContext from '../../hooks/contexts/use-notification-context';

jest.mock('../../hooks/contexts/use-notification-context');

const mockUseNotificationContext = useNotificationContext.default as jest.Mock;

const placeholders = {
  NAME: 'Board or office name',
  START_TIME: 'Start time of standup e.g. 09:00',
  TIMEZONE: 'Timezone of the office e.g. Europe/Berlin',
};

const fillForm = async () => {
  groupuiChange(screen.getByPlaceholderText(placeholders.NAME), 'board-name');
  groupuiChange(screen.getByPlaceholderText(placeholders.START_TIME), '10:00');
  groupuiChange(screen.getByPlaceholderText(placeholders.TIMEZONE), 'Europe/Lisbon');
  groupuiChange(screen.getByPlaceholderText('Name of 1st category'), 'category-1-name');
  groupuiChange(screen.getByPlaceholderText('Description of 1st category'), 'category-1-description');
  groupuiChange(screen.getByPlaceholderText('Name of 2nd category'), 'category-2-name');
  groupuiChange(screen.getByPlaceholderText('Description of 2nd category'), 'category-2-description');
  groupuiChange(screen.getByPlaceholderText('Name of 3rd category'), 'category-3-name');
  groupuiChange(screen.getByPlaceholderText('Description of 3rd category'), 'category-3-description');
  groupuiChange(screen.getByPlaceholderText('Name of 4th category'), 'category-4-name');
  groupuiChange(screen.getByPlaceholderText('Description of 4th category'), 'category-4-description');
};

const server = setupServer();

describe('Add board page', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => server.resetHandlers());
  beforeEach(() => {
    jest.mocked(mockUseNotificationContext).mockReturnValue({ setNotification: () => {} });
  });

  it('renders the form headings and back link', async () => {
    render(
      <Routes>
        <Route path="/boards" element="mock-boards-page" />
        <Route path="/add-board" element={<AddBoard />} />
      </Routes>,
      '/add-board',
    );

    expect(screen.getByText('Add Board')).toBeVisible();
    expect(screen.getByText('Board details')).toBeVisible();
    expect(screen.getByText('Complete the details for the office’s standup')).toBeVisible();
    expect(screen.getByText('Standup categories')).toBeVisible();
    expect(screen.getByText('The office’s standup presentation categories')).toBeVisible();
    expect(screen.getByText('1st Category')).toBeVisible();
    expect(screen.getByText('2nd Category')).toBeVisible();
    expect(screen.getByText('3rd Category')).toBeVisible();
    expect(screen.getByText('4th Category')).toBeVisible();

    await userEvent.click(screen.getByRole('link', { name: 'View all boards' }));
    expect(screen.getByText('mock-boards-page')).toBeVisible();
  });

  it.each`
    name                        | label               | placeholder                       | initialValue
    ${'name'}                   | ${'Name *'}         | ${placeholders.NAME}              | ${''}
    ${'start time'}             | ${'Standup time *'} | ${placeholders.START_TIME}        | ${'09:00'}
    ${'timezone'}               | ${'Timezone *'}     | ${placeholders.TIMEZONE}          | ${'Europe/Berlin'}
    ${'category 1 name'}        | ${'Name *'}         | ${'Name of 1st category'}         | ${'New Faces'}
    ${'category 1 description'} | ${'Description *'}  | ${'Description of 1st category'}  | ${'Announce a new team member/visitor, or a new tasty meal, or exciting place to visit'}
    ${'category 2 name'}        | ${'Name *'}         | ${'Name of 2nd category'}         | ${'Helps and Offers'}
    ${'category 2 description'} | ${'Description *'}  | ${'Description of 2nd category'}  | ${'For when you need help with something or in case you want to offer something (like cake!)'}
    ${'category 3 name'}        | ${'Name *'}         | ${'Name of 3rd category'}         | ${'Interesting'}
    ${'category 3 description'} | ${'Description *'}  | ${'Description of 3rd category'}  | ${'Share something that you think people in the office could be interested in'}
    ${'category 4 name'}        | ${'Name *'}         | ${'Name of 4th category'}         | ${'Events'}
    ${'category 4 description'} | ${'Description *'}  | ${'Description of 4th category'}  | ${'Announce an event that you think people in your lab could be interested in'}
  `('renders the $name field', async ({ placeholder, label, initialValue }) => {
    render(<AddBoard />);

    const input = screen.getByPlaceholderText(placeholder);
    expect(input).toHaveValue(initialValue);
    expect(within(input).getByText(label)).toBeVisible();

    groupuiChange(input, 'my-value');

    expect(input).toHaveValue('my-value');
  });

  it('saves a new board', async () => {
    let requestData: any;
    server.use(
      rest.post(`${process.env.API_URL}/boards`, async (req, res, ctx) => {
        requestData = await req.json();
        return res(ctx.status(201));
      }),
    );

    const mockSetNotification = jest.fn();
    jest.mocked(mockUseNotificationContext).mockReturnValue({
      setNotification: mockSetNotification,
    });

    render(
      <Routes>
        <Route path="/boards" element="mock-boards-page" />
        <Route path="/add-board" element={<AddBoard />} />
      </Routes>,
      '/add-board',
    );

    expect(screen.getByText('Add Board')).toBeVisible();

    await fillForm();
    const button = screen.getByRole('button', { name: 'Save' });

    expect(mockSetNotification).not.toHaveBeenCalled();
    fireEvent.submit(button);

    await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
    await waitFor(() => expect(requestData).toEqual({
      name: 'board-name',
      startTime: '10:00',
      timezone: 'Europe/Lisbon',
      emailFrom: '',
      emailTo: [],
      slackWebhook: '',
      categories: [
        {
          id: '1',
          name: 'category-1-name',
          description: 'category-1-description',
        },
        {
          id: '2',
          name: 'category-2-name',
          description: 'category-2-description',
        },
        {
          id: '3',
          name: 'category-3-name',
          description: 'category-3-description',
        },
        {
          id: '4',
          name: 'category-4-name',
          description: 'category-4-description',
        },
      ],
    }));
    await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('success', 'Board successfully added!'));
    expect(await screen.findByText('mock-boards-page')).toBeVisible();
    expect(screen.queryByText('Add Board')).not.toBeInTheDocument();
  });

  it('calls setNotification with an error when failing to add', async () => {
    // @ts-ignore
    // eslint-disable-next-line no-console
    console.error.mockImplementation(() => null);
    server.use(
      rest.post(`${process.env.API_URL}/boards`, (req, res, ctx) => (
        res(ctx.status(500))
      )),
    );

    const mockSetNotification = jest.fn();
    jest.mocked(mockUseNotificationContext).mockReturnValue({
      setNotification: mockSetNotification,
    });

    render(
      <Routes>
        <Route path="/boards" element="mock-boards-page" />
        <Route path="/add-board" element={<AddBoard />} />
      </Routes>,
      '/add-board',
    );

    await fillForm();
    const button = screen.getByRole('button', { name: 'Save' });

    expect(mockSetNotification).not.toHaveBeenCalled();
    fireEvent.submit(button);

    await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
    await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('danger', 'Oops! There has been error trying to add the board.'));
    expect(button).toHaveAttribute('disabled', 'false');
    expect(screen.getByText('Add Board')).toBeVisible();
    expect(screen.queryByText('mock-boards-page')).not.toBeInTheDocument();
  });

  describe('validation', () => {
    it.each`
      name                        | label             | placeholder                     
      ${'name'}                   | ${'Name'}         | ${placeholders.NAME}            
      ${'start time'}             | ${'Standup time'} | ${placeholders.START_TIME}      
      ${'timezone'}               | ${'Timezone'}     | ${placeholders.TIMEZONE}        
      ${'category 1 name'}        | ${'Name'}         | ${'Name of 1st category'}       
      ${'category 1 description'} | ${'Description'}  | ${'Description of 1st category'}
      ${'category 2 name'}        | ${'Name'}         | ${'Name of 2nd category'}       
      ${'category 2 description'} | ${'Description'}  | ${'Description of 2nd category'}
      ${'category 3 name'}        | ${'Name'}         | ${'Name of 3rd category'}       
      ${'category 3 description'} | ${'Description'}  | ${'Description of 3rd category'}
      ${'category 4 name'}        | ${'Name'}         | ${'Name of 4th category'}       
      ${'category 4 description'} | ${'Description'}  | ${'Description of 4th category'}                  
    `('shows an error when the $name is empty', async ({ label, placeholder }) => {
      render(<AddBoard />);

      await fillForm();

      expect(screen.queryByText(`${label} is required`)).not.toBeInTheDocument();
      groupuiChange(screen.getByPlaceholderText(placeholder), '');

      fireEvent.submit(screen.getByRole('button', { name: 'Save' }));

      expect(await screen.findByText(`${label} is required`)).toBeVisible();
    });

    // TODO: start time and timezone validation
  });
});
