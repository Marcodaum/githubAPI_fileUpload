import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent } from '@testing-library/react';
import { Route, Routes } from 'react-router-dom';
import { render, screen } from '../../test/utils';
import Boards from './index';

const server = setupServer();

describe('Boards page', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => server.resetHandlers());

  it('displays a list of boards', async () => {
    const boardsList = {
      boards: [
        {
          id: 'brunswick',
          name: 'SDC Brunswick',
          timezone: 'Europe/Berlin',
          startTime: '08:00',
        },
        {
          id: 'lisbon',
          name: 'SDC Lisbon',
          timezone: 'Europe/Lisbon',
          startTime: '09:00',
        },
      ],
    };
    server.use(
      rest.get(`${process.env.API_URL}/boards`, (req, res, ctx) => (
        res(ctx.json(boardsList))
      )),
    );

    const mockOnSelect = jest.fn();
    render(
      <Routes>
        <Route path="/boards" element={<Boards onSelect={mockOnSelect} />} />
        <Route path="/" element="mock-board-page" />
      </Routes>,
      '/boards',
    );

    expect(await screen.findByText('Office boards')).toBeVisible();
    expect(screen.getByText('SDC Brunswick')).toBeVisible();
    expect(screen.getByText('08:00 in Europe/Berlin (07:00 in Europe/Lisbon)')).toBeVisible();
    expect(screen.getByText('SDC Lisbon')).toBeVisible();
    expect(screen.getByText('09:00 in Europe/Lisbon')).toBeVisible();

    expect(mockOnSelect).not.toHaveBeenCalled();
    fireEvent.click(screen.getByText('SDC Lisbon'));

    expect(await screen.findByText('mock-board-page')).toBeVisible();
    expect(mockOnSelect).toHaveBeenCalledWith('lisbon');
  });

  it('navigates to the add board page', async () => {
    server.use(
      rest.get(`${process.env.API_URL}/boards`, (req, res, ctx) => (
        res(ctx.json({ boards: [] }))
      )),
    );

    render(
      <Routes>
        <Route path="/boards" element={<Boards onSelect={() => {}} />} />
        <Route path="/add-board" element="mock-add-board-page" />
      </Routes>,
      '/boards',
    );

    fireEvent.click(await screen.findByRole('button', { name: 'Add Board' }));

    expect(await screen.findByText('mock-add-board-page')).toBeVisible();
    expect(screen.queryByText('mock-board-page')).not.toBeInTheDocument();
  });

  it.each`
    page              | route           | buttonText
    ${'add-item'}     | ${'/add-item'}  | ${'Add Item'}
    ${'presentation'} | ${'/present'}   | ${'Present'}
  `('navigates to the $page page', async ({ page, route, buttonText }) => {
    server.use(
      rest.get(`${process.env.API_URL}/boards`, (req, res, ctx) => (
        res(ctx.json({
          boards: [{ id: 'board-id' }],
        }))
      )),
    );

    const mockOnSelect = jest.fn();
    render(
      <Routes>
        <Route path="/boards" element={<Boards onSelect={mockOnSelect} />} />
        <Route path={route} element={`mock-${page}-page`} />
        <Route path="/" element="mock-board-page" />
      </Routes>,
      '/boards',
    );

    expect(mockOnSelect).not.toHaveBeenCalled();
    fireEvent.click(await screen.findByRole('button', { name: buttonText }));

    expect(await screen.findByText(`mock-${page}-page`)).toBeVisible();
    expect(screen.queryByText('mock-board-page')).not.toBeInTheDocument();
    expect(mockOnSelect).toHaveBeenCalledWith('board-id');
  });
});
