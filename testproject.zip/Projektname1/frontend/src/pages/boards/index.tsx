import React, { FC } from 'react';
import {
  GroupuiButton, GroupuiCard, GroupuiIcon, GroupuiLoadingSpinner, GroupuiText,
} from '@group-ui/group-ui-react';
import { useNavigate } from 'react-router-dom';
import { getLocalTimezone, toLocalTime } from '../../utils/dates';
import Container from '../../components/styled/container';
import Flexbox from '../../components/styled/flexbox';
import BoardActionButton from '../../components/pages.boards/board-action-button';
import BoardsGrid from '../../components/styled/boards-grid';
import Oval from '../../components/custom-icons/oval';
import useBoards from '../../hooks/queries/use-boards';
import { Grey1000Headline } from '../../components/styled/grey-text';

export interface PageProps {
  onSelect: (id: string) => void,
}

const Boards: FC<PageProps> = ({ onSelect }) => {
  const navigate = useNavigate();
  const { boardsList, hasLoaded } = useBoards();

  if (!hasLoaded) {
    return <GroupuiLoadingSpinner displayed background="transparent" />;
  }

  const handleBoardClick = (id: string, to: string) => {
    onSelect(id);
    navigate(to);
  };

  const localTimezone = getLocalTimezone();

  return (
    <>
      <Container marginTop={8} marginBottom={9}>
        <Flexbox>
          <Flexbox gap={5}>
            <GroupuiIcon name="home-48" />
            <Grey1000Headline>Office boards</Grey1000Headline>
          </Flexbox>
          <GroupuiButton role="button" icon="plus-24" onClick={() => navigate('/add-board')}>
            Add Board
          </GroupuiButton>
        </Flexbox>
      </Container>
      {boardsList!.boards.map((board) => {
        let standupTime = `${board.startTime} in ${board.timezone}`;
        if (localTimezone !== board.timezone) {
          standupTime += ` (${toLocalTime(board.startTime, board.timezone)} in ${getLocalTimezone()})`;
        }

        return (
          <Container key={board.id} marginBottom={4}>
            <GroupuiCard onClick={() => handleBoardClick(board.id, '/')} interactive>
              <BoardsGrid>
                <Flexbox>
                  <Oval marginRight={5} />
                </Flexbox>
                <div>
                  <GroupuiText>{board.name}</GroupuiText>
                </div>
                <div>
                  <GroupuiText>{standupTime}</GroupuiText>
                </div>
                <Flexbox justifyContent="end" gap={6}>
                  <BoardActionButton onClick={() => handleBoardClick(board.id, '/add-item')} variant="secondary" icon="plus-24">Add Item</BoardActionButton>
                  <BoardActionButton onClick={() => handleBoardClick(board.id, '/present')}>Present</BoardActionButton>
                </Flexbox>
              </BoardsGrid>
            </GroupuiCard>
          </Container>
        );
      })}
    </>
  );
};

export default Boards;
