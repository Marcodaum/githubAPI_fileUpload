import React from 'react';
import userEvent from '@testing-library/user-event';
import { Routes, Route } from 'react-router-dom';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { render, screen } from '../../test/utils';
import Board from './index';
import * as useBoardIdContext from '../../hooks/contexts/use-board-id-context';

jest.mock('../../hooks/contexts/use-board-id-context');

const mockUseBoardIdContext = useBoardIdContext.default as jest.Mock;

const server = setupServer();

describe('Board page', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => server.resetHandlers());
  beforeEach(() => {
    jest.mocked(mockUseBoardIdContext).mockReturnValue('board-id');
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({}))
      )),
    );
  });

  it('renders the board details', async () => {
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({
          id: 'board-id',
          name: 'Hawaii SDC',
          startTime: '13:00',
          timezone: 'Europe/Athens',
          items: [],
        }))
      )),
    );

    render(<Board />);

    expect(await screen.findByText('Hawaii SDC')).toBeVisible();
    expect(screen.getByText('Start: 01:00 PM • Athens (GMT+2)')).toBeVisible();
  });

  it('renders a no items message if empty items', async () => {
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({ items: [] }))
      )),
    );

    render(<Board />);

    expect(await screen.findByText('There are no current or upcoming standup items')).toBeVisible();
  });

  it('renders the standup items', async () => {
    const items = [
      {
        id: 'item-1',
        startDate: '2023-06-01',
        endDate: '2023-06-01',
        title: 'title-1',
        author: 'author-1',
        description: 'description-1',
      },
      {
        id: 'item-2',
        startDate: '2022-10-01',
        endDate: '2023-10-02',
        title: 'title-2',
        author: 'author-2',
        description: 'description-2',
        images: ['/images/item-2.png'],
      },
      {
        id: 'item-3',
        startDate: '2023-10-01',
        endDate: '2023-11-02',
        title: 'title-3',
        author: 'author-3',
        description: 'description-3',
        images: ['/images/item-3.png'],
      },
    ];

    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({ items }))
      )),
    );

    render(<Board />);

    expect(screen.queryByText('There are no current or upcoming standup items')).not.toBeInTheDocument();

    expect(await screen.findByText('title-1')).toBeVisible();
    expect(screen.getByText('Thu 01 Jun')).toBeVisible();
    expect(screen.getByText('author-1')).toBeVisible();
    expect(screen.getByText('description-1')).toBeVisible();
    expect(screen.getByText('title-2')).toBeVisible();
    expect(screen.getByText('Sat 01 - Mon 02 Oct')).toBeVisible();
    expect(screen.getByText('author-2')).toBeVisible();
    expect(screen.getByText('description-2')).toBeVisible();
    expect(screen.getByText('title-3')).toBeVisible();
    expect(screen.getByText('Sun 01 Oct - Thu 02 Nov')).toBeVisible();
    expect(screen.getByText('author-3')).toBeVisible();
    expect(screen.getByText('description-3')).toBeVisible();
    expect(screen.getAllByText('Image Uploaded')).toHaveLength(2);
  });

  it.each`
    page          | buttonRole  | buttonText
    ${'boards'}   | ${'link'}   | ${'View all boards'}
    ${'add-item'} | ${'button'} | ${'Add item'}
    ${'present'}  | ${'button'} | ${'Start presenting'}
  `('navigates to the $page page', async ({ page, buttonRole, buttonText }) => {
    const mockPage = `mock-${page}-page`;
    render(
      <Routes>
        <Route path="/" element={<Board />} />
        <Route path={`/${page}`} element={mockPage} />
      </Routes>,
    );
    expect(screen.queryByText(mockPage)).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole(buttonRole, { name: buttonText }));
    expect(screen.getByText(mockPage)).toBeVisible();
  });

  it('navigates to the edit item page', async () => {
    const items = [
      {
        id: 'item-1',
        startDate: '2023-06-01',
        endDate: '2023-06-01',
        title: 'Item 1',
      },
    ];

    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({ items }))
      )),
    );

    render(
      <Routes>
        <Route path="/" element={<Board />} />
        <Route path="/edit-item/item-1" element="mock-edit-item-page" />
      </Routes>,
    );

    await userEvent.click(await screen.findByText('Item 1'));
    expect(screen.getByText('mock-edit-item-page')).toBeVisible();
  });
});
