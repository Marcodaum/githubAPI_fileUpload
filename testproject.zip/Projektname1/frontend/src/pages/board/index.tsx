import React from 'react';
import { useNavigate } from 'react-router-dom';
import { parse } from 'date-fns';
import { format } from 'date-fns-tz';
import { GroupuiButton, GroupuiHeadline, GroupuiText } from '@group-ui/group-ui-react';
import BoardItemList from '../../components/pages.board/board-item-list';
import Flexbox from '../../components/styled/flexbox';
import Breadcrumb from '../../components/layout/breadcrumb';
import useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import useBoard from '../../hooks/queries/use-board';
import Container from '../../components/styled/container';

const Board = () => {
  const navigate = useNavigate();
  const boardId = useBoardIdContext();
  const { board } = useBoard(boardId);

  let start = '';
  if (board.startTime && board.timezone) {
    const startTime = parse(board.startTime, 'H:mm', new Date());
    const pattern = `hh:mm a '• ${board.timezone.split('/')[1]}' (O)`;
    start = format(startTime, pattern, { timeZone: board.timezone });
  }

  return (
    <>
      <Breadcrumb url="/boards" label="View all boards" />
      <Flexbox>
        <Container>
          <GroupuiHeadline>{board.name}</GroupuiHeadline>
          <GroupuiText>{`Start: ${start}`}</GroupuiText>
        </Container>

        <Flexbox gap={3}>
          <GroupuiButton variant="secondary" role="button" icon="plus-24" onClick={() => navigate('/add-item')}>
            Add item
          </GroupuiButton>
          <GroupuiButton role="button" icon="play-24" onClick={() => navigate('/present')}>
            Start presenting
          </GroupuiButton>
        </Flexbox>
      </Flexbox>

      <BoardItemList />
    </>
  );
};

export default Board;
