import React, { useState } from 'react';
import Flexbox from '../../../components/styled/flexbox';
import useStandupContext from '../../../hooks/contexts/use-standup-context';
import { getCountdownForTime } from '../../../utils/countdown-calculator';
import CountdownText from '../../../components/styled/countdown-text';
import StartPresentingButton from '../../../components/pages.present-countdown/start-presenting-button';

const showRemainingTimeInMinutesAndSeconds = (remainingTimeInSeconds: number): string => {
  const remainingMinutes = Math.floor(remainingTimeInSeconds / 60);
  const remainingSeconds = remainingTimeInSeconds - (remainingMinutes * 60);
  return `${remainingMinutes < 10 ? '0' : ''}${remainingMinutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
};

const PresentCountdown = () => {
  const { board: { categories } } = useStandupContext();
  const { board: { startTime } } = useStandupContext();
  const firstCategory = categories[0];

  const [countdown, setCountdown] = useState(getCountdownForTime(startTime));
  setTimeout(() => {
    if (countdown !== 0) setCountdown(countdown - 1);
  }, 1000);

  return (
    <Flexbox direction="column" justifyContent="center" height="100%">
      <CountdownText>
        {showRemainingTimeInMinutesAndSeconds(countdown)}
      </CountdownText>
      {countdown === 0 && <StartPresentingButton category={firstCategory} />}
    </Flexbox>
  );
};

export default PresentCountdown;
