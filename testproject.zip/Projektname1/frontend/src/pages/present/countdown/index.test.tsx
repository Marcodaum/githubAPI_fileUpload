import React from 'react';
import { Route, Routes } from 'react-router-dom';
import { act, fireEvent, waitFor } from '@testing-library/react';
import { render, screen } from '../../../test/utils';
import PresentCountdown from './index';
import * as useStandupContext from '../../../hooks/contexts/use-standup-context';

jest.mock('../../../hooks/contexts/use-standup-context');

const mockUseStandupContext = useStandupContext.default as jest.Mock;

describe('Presentation countdown page', () => {
  const mockStandup = {
    board: {
      id: 'board-id',
      name: 'board-name',
      startTime: '09:00',
      timezone: 'Europe/Lisbon',
      categories: [
        {
          id: 'category-1',
          name: 'New Faces',
          description: 'New specimens in the office',
        },
        {
          id: 'category-2',
          name: 'Helps and Offers',
          description: 'Help me!',
        },
      ],
      items: [],
    },
    items: [{
      category: 'category-1',
      startDate: '2023-06-01',
      endDate: '2023-06-01',
      title: 'A New Face',
      author: 'Them',
      description: 'This is a description',
      link: 'www.place.com',
    },
    {
      category: 'category-2',
      startDate: '2022-10-01', // SAT
      endDate: '2023-10-02', // MON
      title: 'An Offer',
      author: 'Us',
      description: 'This is a good description',
      link: 'www.website.com',
    }],
  };

  beforeEach(() => {
    jest.useFakeTimers();
    jest.mocked(mockUseStandupContext).mockReturnValue(
      mockStandup,
    );
  });

  const extractBeginHourAndMinuteFromTimeString = (timeString: string): number[] => timeString
    .split(':')
    .map((time) => Number.parseInt(time, 10));

  // eslint-disable-next-line max-len
  const [beginHour, beginMinute] = extractBeginHourAndMinuteFromTimeString(mockStandup.board.startTime);

  it('links to the first category page', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour, beginMinute, 0, 0));

    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    fireEvent.click(screen.getByText('Start presenting'));
    expect(await screen.findByText(mockStandup.board.categories[0].name)).toBeVisible();
  });

  it('should show countdown with correct time', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour - 1, beginMinute - 5, 0, 0));
    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    expect(await screen.findByText('65:00')).toBeVisible();
  });

  it('should update the countdown with correct time after one second', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour - 1, beginMinute - 5, 0, 0));
    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    act(() => {
      jest.advanceTimersByTime(1000);
      jest.runOnlyPendingTimers();
    });

    await waitFor(() => expect(screen.getByText('64:59')).toBeTruthy());
  });

  it('should not further update the countdown if it reached the end', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour, beginMinute, 0, 0));
    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    act(() => {
      jest.advanceTimersByTime(1000);
      jest.runOnlyPendingTimers();
    });

    await waitFor(() => expect(screen.getByText('00:00')).toBeTruthy());
  });

  it('should show start presenting button if countdown reached', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour, beginMinute, 0, 0));
    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    expect(await screen.queryByText('Start presenting')).toBeVisible();
  });

  it('should not show start presenting button if countdown not reached zero', async () => {
    jest.setSystemTime(new Date(2022, 1, 1, beginHour - 1, beginMinute - 5, 0, 0));
    render(
      <Routes>
        <Route path="present" element={<PresentCountdown />} />
        <Route path={`/present/${mockStandup.board.categories[0].id}`} element={mockStandup.board.categories[0].name} />
      </Routes>,
      '/present',
    );

    expect(await screen.queryByText('Start presenting')).toBeFalsy();
  });
});
