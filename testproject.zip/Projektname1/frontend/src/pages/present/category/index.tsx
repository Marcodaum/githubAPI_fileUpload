import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { GroupuiHeadline } from '@group-ui/group-ui-react';
import useStandupContext from '../../../hooks/contexts/use-standup-context';
import CategoryItem from '../../../components/pages.present-category/category-item';
import { categoryOptions } from '../../../utils/constants';
import Category from '../../../models/category';
import BoardItem from '../../../models/board-item';

const nextUrl = (
  categoryId: string | undefined,
  categories: Category[],
  items: BoardItem[],
): string => {
  const categoryIndex = categories.findIndex((c) => c.id === categoryId);
  const isLast = categoryIndex + 1 === categories.length;
  if (isLast) return '/';

  const isBeforeGlobal = categories[categoryIndex + 1].id === categoryOptions.global.id;
  if (isBeforeGlobal) {
    const isGlobalEmpty = !items.find((i) => i.category === categoryOptions.global.id);
    if (isGlobalEmpty) return '/';
  }

  return `/present/${categories[categoryIndex + 1].id}`;
};

const previousUrl = (
  categoryId: string | undefined,
  categories: Category[],
): string => {
  const categoryIndex = categories.findIndex((c) => c.id === categoryId);
  const isFirst = categoryIndex === 0;
  if (isFirst) return '/present';

  return `/present/${categories[categoryIndex - 1].id}`;
};

const PresentCategory = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();

  const { board, items } = useStandupContext();
  const categories = [...board.categories, categoryOptions.global];

  const category = categories.find((c) => c.id === categoryId);
  if (!category) throw new Error('Category not found');

  const categoryItems = items.filter((i) => i.category === categoryId);

  const handleKeyUp = (event: KeyboardEvent) => {
    switch (event.code) {
      case 'ArrowRight':
      case 'Space':
        navigate(nextUrl(categoryId, categories, items));
        return;
      case 'ArrowLeft':
      case 'Backspace':
        navigate(previousUrl(categoryId, categories));
    }
  };

  useEffect(() => {
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [categoryId]);

  return (
    <>
      <GroupuiHeadline heading="h2">{category?.name}</GroupuiHeadline>
      {categoryItems.map((item, itemIndex) => (
        <CategoryItem key={item.id} item={item} isLast={itemIndex + 1 === categoryItems.length} />
      ))}
    </>
  );
};

export default PresentCategory;
