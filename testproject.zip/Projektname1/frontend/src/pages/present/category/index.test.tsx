import React from 'react';
import { Route, Routes, Outlet } from 'react-router-dom';
import { fireEvent } from '@testing-library/react';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import { render, screen } from '../../../test/utils';
import PresentCategory from './index';
import * as useStandupContext from '../../../hooks/contexts/use-standup-context';

jest.mock('../../../hooks/contexts/use-standup-context');

const mockUseStandupContext = useStandupContext.default as jest.Mock;

const mockBoard = {
  id: 'board-id',
  categories: [
    {
      id: 'category-1',
      name: 'Category #1',
      description: 'Category #1 description',
    },
    {
      id: 'category-2',
      name: 'Category #2',
      description: 'Category #2 description',
    },
  ],
};

describe('Presentation category page', () => {
  beforeEach(() => {
    jest.mocked(mockUseStandupContext).mockReturnValue({
      board: mockBoard,
      items: [{
        id: 'global-item',
        category: 'global',
        title: 'Global Item',
      }],
    });
  });

  it('renders the appropriate category name and item details', async () => {
    jest.mocked(mockUseStandupContext).mockReturnValue({
      board: mockBoard,
      items: [
        {
          id: 'item-1',
          category: 'category-1',
          title: 'Item #1',
          author: 'Author #1',
          description: 'Item #1 description',
          link: 'http://example.com',
        },
        {
          id: 'item-2',
          category: 'category-1',
          title: 'Item #2',
          author: 'Author #2',
          description: 'Item #2 description',
        },
        {
          id: 'item-3',
          category: 'category-2',
          title: 'Item #3',
        },
      ],
    });

    render(
      <Routes>
        <Route path="/present/:categoryId" element={<PresentCategory />} />
      </Routes>,
      '/present/category-1',
    );

    expect(await screen.findByText('Category #1')).toBeVisible();

    expect(screen.getByText('Item #1')).toBeVisible();
    expect(screen.getByText('Item #1 description')).toBeVisible();
    expect(screen.getByText('Author #1')).toBeVisible();

    const button = screen.getByRole('button', { name: 'See more' });
    expect(button).toHaveAttribute('url', 'http://example.com');
    expect(button).toHaveAttribute('target', 'blank');

    expect(screen.getByText('Item #2')).toBeVisible();
    expect(screen.getByText('Item #2 description')).toBeVisible();
    expect(screen.getByText('Author #2')).toBeVisible();

    expect(screen.queryByText('Item #3')).not.toBeInTheDocument();
  });

  it('throws an error when the category does not exist', async () => {
    // @ts-ignore
    // eslint-disable-next-line no-console
    console.error.mockImplementation(() => null);

    const mockOnError = jest.fn();
    render(
      <Routes>
        <Route
          path="/"
          element={(
            <ReactErrorBoundary FallbackComponent={() => <>Error</>} onError={mockOnError}>
              <Outlet />
            </ReactErrorBoundary>
        )}
        >
          <Route path="/present/:categoryId" element={<PresentCategory />} />
        </Route>
      </Routes>,
      '/present/some-category',
    );

    expect(await screen.findByText('Error')).toBeVisible();
    expect(mockOnError).toHaveBeenCalledWith(new Error('Category not found'), expect.any(Object));
  });

  it.each`
    keyEvent                                      | categoryId      | currentPage       | expectedPage
    ${{ key: ' ', code: 'Space' }}                | ${'category-1'} | ${'Category #1'}  | ${'Category #2'}
    ${{ key: 'ArrowRight', code: 'ArrowRight' }}  | ${'category-1'} | ${'Category #1'}  | ${'Category #2'}
    ${{ key: 'ArrowLeft', code: 'ArrowLeft' }}    | ${'category-2'} | ${'Category #2'}  | ${'Category #1'}
    ${{ key: 'Backspace', code: 'Backspace' }}    | ${'category-2'} | ${'Category #2'}  | ${'Category #1'}    
    ${{ key: 'ArrowLeft', code: 'ArrowLeft' }}    | ${'category-1'} | ${'Category #1'}  | ${'mock-countdown-page'}
    ${{ key: 'ArrowRight', code: 'ArrowRight' }}  | ${'category-2'} | ${'Category #2'}  | ${'Global'}
    ${{ key: 'ArrowRight', code: 'ArrowRight' }}  | ${'global'}     | ${'Global'}       | ${'mock-board-page'}
  `('navigates to the $expectedPage page when the $keyEvent.code key is pressed', async ({
    keyEvent, categoryId, currentPage, expectedPage,
  }) => {
    render(
      <Routes>
        <Route path="/" element="mock-board-page" />
        <Route path="/present" element="mock-countdown-page" />
        <Route path="/present/:categoryId" element={<PresentCategory />} />
      </Routes>,
      `/present/${categoryId}`,
    );

    expect(await screen.findByText(currentPage)).toBeVisible();

    fireEvent.keyUp(screen.getByText(currentPage), keyEvent);

    expect(await screen.findByText(expectedPage)).toBeVisible();
  });

  it('re-registers event listeners to navigate more than once', async () => {
    jest.mocked(mockUseStandupContext).mockReturnValue({
      board: {
        ...mockBoard,
        categories: [
          ...mockBoard.categories,
          {
            id: 'category-3',
            name: 'Category #3',
            description: 'Category #3 description',
          },
        ],
      },
      items: [],
    });

    render(
      <Routes>
        <Route path="/present/:categoryId" element={<PresentCategory />} />
      </Routes>,
      '/present/category-1',
    );

    expect(await screen.findByText('Category #1')).toBeVisible();

    fireEvent.keyUp(screen.getByText('Category #1'), { key: 'ArrowRight', code: 'ArrowRight' });

    expect(await screen.findByText('Category #2')).toBeVisible();

    fireEvent.keyUp(screen.getByText('Category #2'), { key: 'ArrowRight', code: 'ArrowRight' });

    expect(await screen.findByText('Category #3')).toBeVisible();
  });

  it('does not render the global category if there are no global items', async () => {
    jest.mocked(mockUseStandupContext).mockReturnValue({
      board: mockBoard,
      items: [{
        id: 'item-1',
        category: 'category-1',
        title: 'Item #1',
      }],
    });

    render(
      <Routes>
        <Route path="/" element="mock-board-page" />
        <Route path="/present/:categoryId" element={<PresentCategory />} />
      </Routes>,
      '/present/category-2',
    );

    expect(await screen.findByText('Category #2')).toBeVisible();

    fireEvent.keyUp(screen.getByText('Category #2'), { key: 'ArrowRight', code: 'ArrowRight' });

    expect(await screen.findByText('mock-board-page')).toBeVisible();
    expect(screen.queryByText('Global')).not.toBeInTheDocument();
  });
});
