import React, { useState } from 'react';
import { GroupuiButton, GroupuiHeadline } from '@group-ui/group-ui-react';
import { useForm } from 'react-hook-form';
import { useMutation } from 'react-query';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import apiFetch from '../../utils/api-fetch';
import Container from '../../components/styled/container';
import Breadcrumb from '../../components/layout/breadcrumb';
import useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import useBoard from '../../hooks/queries/use-board';
import Category from '../../models/category';
import useNotificationContext from '../../hooks/contexts/use-notification-context';
import NotificationType from '../../models/notification-type';
import ImageInput from '../../components/form/image-input';
import ItemFields from '../../components/pages.add-edit-item/item-fields';
import { dateOptions, categoryOptions } from '../../utils/constants';
import { today } from '../../utils/dates';

interface AddItemFields {
  category: string,
  title: string,
  description: string,
  author: string,
  link: string,
  images: FileList | undefined,
  startDate: string,
  endDate: string,
}

interface UploadResponse {
  imageUrl: string,
}

const StyledContainer = styled.div`
  text-align: inherit;
  margin-top: var(--groupui-spacing-8);
  display: flex;
  column-gap: var(--groupui-spacing-7);
  justify-content: left;
`;

const uploadImages = async (images: FileList | undefined): Promise<string[]> => {
  if (!images || images.length === 0) return Promise.resolve([]);

  const uploadPromises = Array.from(images)
    .map((image) => (
      apiFetch(`images/${image.name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'multipart/form-data' },
        body: image,
      }).then((res) => res.json().then((response: UploadResponse) => response.imageUrl))
    ));
  return Promise.all(uploadPromises);
};

const AddItem = () => {
  const navigate = useNavigate();
  const boardId = useBoardIdContext();
  const { setNotification } = useNotificationContext();
  const { board } = useBoard(boardId);

  const defaultValues: AddItemFields = {
    category: '',
    title: '',
    description: '',
    author: '',
    link: '',
    images: undefined,
    startDate: today(),
    endDate: today(),
  };
  const {
    control, register, setValue, handleSubmit, watch,
  } = useForm({ defaultValues });

  const addItem = useMutation<Response, Error, AddItemFields, any>(
    async ({ images, ...data }: AddItemFields) => {
      const body = {
        images: await uploadImages(images),
        ...data,
      };

      return apiFetch(`boards/${boardId}/items`, {
        method: 'POST',
        body: JSON.stringify(body),
      });
    },
    {
      onSuccess: () => {
        setNotification(NotificationType.Success, 'Item successfully added!');
        navigate('/');
      },
      onError: () => setNotification(NotificationType.Error, 'Oops! There has been error trying to add the item.'),
    },
  );

  const [isCategorySelected, setIsCategorySelected] = useState(true);

  const onSubmit = handleSubmit((data) => {
    if (!data.category) {
      setIsCategorySelected(false);
      return;
    }

    setIsCategorySelected(true);

    addItem.mutate(data);
  });
  const categories : Category[] = [...board.categories, categoryOptions.global];

  return (
    <>
      <Breadcrumb url="/" label={board.name} />
      <GroupuiHeadline heading="h2">Add Item</GroupuiHeadline>
      <form onSubmit={onSubmit}>
        <ItemFields
          watch={watch}
          control={control}
          setValue={setValue}
          initialDateOption={dateOptions.TODAY}
          categories={categories}
          isCategorySelected={isCategorySelected}
        />
        <Container marginTop={8}>
          <ImageInput
            label="Images"
            register={register}
            name="images"
          />
        </Container>
        <StyledContainer>
          <GroupuiButton
            role="button"
            type="submit"
            disabled={addItem.isLoading}
            icon="add-16"
          >
            Add Item
          </GroupuiButton>
        </StyledContainer>
      </form>
    </>
  );
};

export default AddItem;
