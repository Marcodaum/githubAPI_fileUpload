import React from 'react';
import {
  act, fireEvent, waitFor, within,
} from '@testing-library/react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { Route, Routes } from 'react-router-dom';
import userEvent from '@testing-library/user-event';
import { Simulate } from 'react-dom/test-utils';
import { groupuiChange, render, screen } from '../../test/utils';
import AddItem from './index';
import * as useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import * as useNotificationContext from '../../hooks/contexts/use-notification-context';

jest.mock('../../hooks/contexts/use-board-id-context');
jest.mock('../../hooks/contexts/use-notification-context');

const mockUseBoardIdContext = useBoardIdContext.default as jest.Mock;
const mockUseNotificationContext = useNotificationContext.default as jest.Mock;

const placeholders = {
  TITLE: 'Title',
  DESCRIPTION: 'Description',
  AUTHOR: 'Author',
  LINK: 'Paste your link here',
  IMAGES: 'Images',
  DATEPICKER: 'The item will be displayed in the standup board between this dates.',
};

const fillForm = async (categoryName: string = 'Global') => {
  fireEvent.click(await screen.findByText(categoryName));
  groupuiChange(screen.getByPlaceholderText(placeholders.TITLE), 'title');
  groupuiChange(screen.getByPlaceholderText(placeholders.DESCRIPTION), 'description');
  groupuiChange(screen.getByPlaceholderText(placeholders.AUTHOR), 'author');
  groupuiChange(screen.getByPlaceholderText(placeholders.LINK), 'link');
};

const server = setupServer();

describe('Add item page', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => server.resetHandlers());
  beforeEach(() => {
    window.URL.createObjectURL = (file: File) => file.name;

    jest.mocked(mockUseBoardIdContext).mockReturnValue('board-id');
    jest.mocked(mockUseNotificationContext).mockReturnValue({ setNotification: () => {} });
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({ categories: [] }))
      )),
    );
  });

  it('renders the board heading and categories', async () => {
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({
          id: 'board-id',
          name: 'Hawaii SDC',
          categories: [
            {
              id: 'category-1',
              name: 'New Faces',
              description: 'New specimens in the office',
            },
            {
              id: 'category-2',
              name: 'Helps and Offers',
              description: 'Help me!',
            },
          ],
        }))
      )),
    );

    render(
      <Routes>
        <Route path="/" element="mock-board-page" />
        <Route path="/add-item" element={<AddItem />} />
      </Routes>,
      '/add-item',
    );

    expect(screen.getAllByText('Add Item').length).toBe(2);
    expect(screen.getByText('Choose the category')).toBeVisible();
    expect(screen.getByText('When will the item be presented?')).toBeVisible();
    expect(screen.getByText('The item will be displayed in the standup board on this date.')).toBeVisible();
    expect(await screen.findByText('Hawaii SDC')).toBeVisible();
    expect(screen.getByText('New Faces')).toBeVisible();
    expect(screen.getByText('New specimens in the office')).toBeVisible();
    expect(screen.getByText('Helps and Offers')).toBeVisible();
    expect(screen.getByText('Help me!')).toBeVisible();
    expect(screen.getByText('Global')).toBeVisible();
    expect(screen.getByText('Items that are shared in all office standups')).toBeVisible();

    await userEvent.click(screen.getByRole('link', { name: 'Hawaii SDC' }));
    expect(screen.getByText('mock-board-page')).toBeVisible();
  });

  it('renders the board file input as file input', async () => {
    const file1 = new File(['(⌐□_□)'], 'chucknorris.png', { type: 'image/png' });
    const file2 = new File(['(⌐□_□)'], 'zepovinho.jpeg', { type: 'image/jpeg' });
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({
          id: 'board-id',
          name: 'Hawaii SDC',
          categories: [],
        }))
      )),
    );

    render(<AddItem />);

    const input = screen.getByLabelText('Upload');
    expect(input).toHaveAttribute('accept', 'image/png, image/jpeg, image/gif');
    expect(input).toHaveAttribute('multiple', '');

    act(() => {
      // @ts-ignore
      Simulate.change(input, { target: { files: [file1, file2] } });
    });

    expect(await screen.findByAltText('chucknorris.png')).toBeVisible();
    expect(await screen.findByAltText('zepovinho.jpeg')).toBeVisible();
  });

  it.each`
    name              | label             | placeholder
    ${'title'}        | ${'Title *'}      | ${placeholders.TITLE}
    ${'description'}  | ${'Description'}  | ${placeholders.DESCRIPTION}
    ${'author'}       | ${'Author *'} | ${placeholders.AUTHOR}
    ${'link'}         | ${'Link'}         | ${placeholders.LINK}
  `('renders the $name field', async ({ placeholder, label }) => {
    render(<AddItem />);

    const input = screen.getByPlaceholderText(placeholder);
    expect(input).toHaveValue('');
    expect(within(input).getByText(label)).toBeVisible();

    groupuiChange(input, 'my-value');

    expect(input).toHaveValue('my-value');
  });

  describe('saving', () => {
    let requestData: any;
    beforeEach(() => {
      jest.useFakeTimers({ now: new Date(2022, 3, 25) });

      server.use(
        rest.post(`${process.env.API_URL}/boards/board-id/items`, async (req, res, ctx) => {
          requestData = await req.json();
          return res(ctx.status(201));
        }),
        rest.post(`${process.env.API_URL}/images/:fileName`, (req, res, ctx) => res(ctx.json({
          imageUrl: `saved-${req.params.fileName}`,
        }))),
      );
    });
    afterEach(() => {
      requestData = undefined;
    });

    it.each`
      name          | categoryName      | categoryId
      ${'standup'}  | ${'My Category'}  | ${'category-1'}
      ${'global'}   | ${'Global'}       | ${'global'}
    `('saves a new $name item for today', async ({ categoryName, categoryId }) => {
      server.use(
        rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
          res(ctx.json({
            id: 'board-id',
            categories: [{ id: 'category-1', name: 'My Category' }],
          }))
        )),
      );

      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      const file1 = new File(['(⌐□_□)'], 'chucknorris.png', { type: 'image/png' });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/add-item" element={<AddItem />} />
        </Routes>,
        '/add-item',
      );

      expect(screen.getAllByText('Add Item')[0]).toBeVisible();

      await fillForm(categoryName);

      const input = screen.getByLabelText('Upload');
      act(() => {
        userEvent.upload(input, file1);
      });
      expect(await screen.findByAltText('chucknorris.png')).toBeVisible();

      const button = screen.getByRole('button', { name: 'Add Item' });

      expect(mockSetNotification).not.toHaveBeenCalled();
      fireEvent.submit(button);

      await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
      await waitFor(() => expect(requestData).toEqual({
        title: 'title',
        description: 'description',
        author: 'author',
        link: 'link',
        startDate: '2022-04-25',
        endDate: '2022-04-25',
        images: ['saved-chucknorris.png'],
        category: categoryId,
      }));
      await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('success', 'Item successfully added!'));
      expect(await screen.findByText('mock-board-page')).toBeVisible();
      expect(screen.queryByText('Add Item')).not.toBeInTheDocument();
    });

    it.each`
      name              | button              | startDate        | endDate
      ${'today'}        | ${'Today'}          | ${'2022-04-25'} | ${'2022-04-25'}
      ${'tomorrow'}     | ${'Tomorrow'}       | ${'2022-04-26'} | ${'2022-04-26'}
    `('changes the date to $name', async ({ button, startDate, endDate }) => {
      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/add-item" element={<AddItem />} />
        </Routes>,
        '/add-item',
      );

      await fillForm();

      fireEvent.click(screen.getByText(button));

      expect(screen.queryByPlaceholderText(placeholders.DATEPICKER)).not.toBeInTheDocument();

      fireEvent.submit(screen.getByRole('button', { name: 'Add Item' }));

      expect(await screen.findByText('mock-board-page')).toBeVisible();
      expect(requestData.startDate).toEqual(startDate);
      expect(requestData.endDate).toEqual(endDate);
    });

    it('changes the date to a range', async () => {
      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/add-item" element={<AddItem />} />
        </Routes>,
        '/add-item',
      );

      await fillForm();

      fireEvent.click(screen.getByText('Pick a date'));

      groupuiChange(screen.getByPlaceholderText(placeholders.DATEPICKER), '2022-04-26:2022-04-28');

      fireEvent.submit(screen.getByRole('button', { name: 'Add Item' }));

      expect(await screen.findByText('mock-board-page')).toBeVisible();
      expect(requestData.startDate).toEqual('2022-04-26');
      expect(requestData.endDate).toEqual('2022-04-28');
    });
  });

  it('calls setNotification with an error when failing to add', async () => {
    // @ts-ignore
    // eslint-disable-next-line no-console
    console.error.mockImplementation(() => null);
    server.use(
      rest.post(`${process.env.API_URL}/boards/board-id/items`, (req, res, ctx) => (
        res(ctx.status(500))
      )),
    );

    const mockSetNotification = jest.fn();
    jest.mocked(mockUseNotificationContext).mockReturnValue({
      setNotification: mockSetNotification,
    });

    render(
      <Routes>
        <Route path="/" element="mock-board-page" />
        <Route path="/add-item" element={<AddItem />} />
      </Routes>,
      '/add-item',
    );

    await fillForm();
    const button = screen.getByRole('button', { name: 'Add Item' });

    expect(mockSetNotification).not.toHaveBeenCalled();
    fireEvent.submit(button);

    await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
    await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('danger', 'Oops! There has been error trying to add the item.'));
    expect(button).toHaveAttribute('disabled', 'false');
    expect(screen.getAllByText('Add Item')[0]).toBeVisible();
    expect(screen.queryByText('mock-board-page')).not.toBeInTheDocument();
  });

  describe('validation', () => {
    it.each([
      'Title',
      'Author',
    ])('shows a validation error for required %s', async (name) => {
      render(<AddItem />);

      expect(screen.queryByText(`${name} is required`)).not.toBeInTheDocument();

      fireEvent.submit(screen.getByRole('button', { name: 'Add Item' }));

      expect(await screen.findByText(`${name} is required`)).toBeVisible();
    });
  });

  it('calls setNotification with an error when trying to add an item without category', async () => {
    render(<AddItem />);

    groupuiChange(screen.getByPlaceholderText(placeholders.TITLE), 'title');
    groupuiChange(screen.getByPlaceholderText(placeholders.AUTHOR), 'author');

    expect(screen.queryByText('Category is required')).not.toBeInTheDocument();

    fireEvent.submit(screen.getByRole('button', { name: 'Add Item' }));

    expect(await screen.findByText('Category is required')).toBeVisible();
  });
});
