import React, { useEffect, useState } from 'react';
import {
  GroupuiButton,
  GroupuiHeadline,
  GroupuiLoadingSpinner,
  GroupuiModal,
  GroupuiText,
} from '@group-ui/group-ui-react';
import { useForm } from 'react-hook-form';
import { useMutation } from 'react-query';
import { useNavigate, useParams } from 'react-router-dom';
import apiFetch from '../../utils/api-fetch';
import Breadcrumb from '../../components/layout/breadcrumb';
import useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import useBoard from '../../hooks/queries/use-board';
import Category from '../../models/category';
import useNotificationContext from '../../hooks/contexts/use-notification-context';
import NotificationType from '../../models/notification-type';
import ItemFields from '../../components/pages.add-edit-item/item-fields';
import { dateOptions, categoryOptions } from '../../utils/constants';
import Flexbox from '../../components/styled/flexbox';

interface EditItemFields {
  category: string,
  title: string,
  description: string,
  author: string,
  link: string,
  startDate: string,
  endDate: string,
  images: string [],
}

const EditItem = () => {
  const navigate = useNavigate();
  const boardId = useBoardIdContext();
  const { setNotification } = useNotificationContext();
  const { board, hasLoaded } = useBoard(boardId);
  const { itemId } = useParams();
  const [ deleteModalVisible, setDeleteModalVisible ] = useState(false);

  const updateItem = useMutation<Response, Error, EditItemFields, any>(
    (data: EditItemFields) => apiFetch(`boards/${boardId}/items/${itemId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
    {
      onSuccess: () => {
        setNotification(NotificationType.Success, 'Item successfully updated!');
        navigate('/');
      },
      onError: () => setNotification(NotificationType.Error, 'Oops! There has been error trying to update the item.'),
    },
  );

  const deleteItem = useMutation<Response, Error, void, any>(
    () => apiFetch(`boards/${boardId}/items/${itemId}`, {
      method: 'DELETE',
    }),
    {
      onSuccess: () => {
        setNotification(NotificationType.Success, 'Item successfully deleted!');
        navigate('/');
      },
      onError: () => setNotification(NotificationType.Error, 'Oops! There has been error trying to update the item.'),
    },
  );

  const {
    control, setValue, handleSubmit, reset, watch,
  } = useForm<EditItemFields>();

  useEffect(() => {
    if (!hasLoaded) return;

    const item = board.items.find((i) => i.id === itemId);
    if (!item) {
      throw new Error('Item not found');
    }

    const defaultValues: EditItemFields = {
      category: item.category || '',
      title: item.title || '',
      description: item.description || '',
      author: item.author || '',
      link: item.link || '',
      startDate: item.startDate || '',
      endDate: item.endDate || '',
      images: item.images || [],
    };
    reset(defaultValues);
  }, [board.items.length, hasLoaded]);

  const [isCategorySelected, setIsCategorySelected] = useState(true);

  const onSubmit = handleSubmit((data) => {
    if (!data.category) {
      setIsCategorySelected(false);
      return;
    }

    setIsCategorySelected(true);

    updateItem.mutate(data);
  });
  const onDeleteConfirm = () => deleteItem.mutate();
  const categories : Category[] = [...board.categories, categoryOptions.global];
  const openDeleteModal = () => setDeleteModalVisible(true);
  const closeDeleteModal = () => setDeleteModalVisible(false);

  if (!hasLoaded) {
    return <GroupuiLoadingSpinner title="Loading..." displayed background="transparent" />;
  }

  return (
    <>
      <Breadcrumb url="/" label={board.name} />
      <GroupuiHeadline heading="h2">Edit Item</GroupuiHeadline>
      {deleteModalVisible && (
        (
          <GroupuiModal
            displayed
            disableBackdropClose
            padding="40px"
            onGroupuiModalClose={closeDeleteModal}
          >
            <GroupuiText>The item will be ejected to space, are you sure about that?</GroupuiText>
            <Flexbox marginTop={8} gap={7} justifyContent="flex-end">
              <GroupuiButton role="button" variant="secondary" onClick={closeDeleteModal}>Cancel</GroupuiButton>
              <GroupuiButton role="button" onClick={onDeleteConfirm}>Confirm</GroupuiButton>
            </Flexbox>
          </GroupuiModal>
        )
      )}
      <form onSubmit={onSubmit}>
        <ItemFields
          watch={watch}
          control={control}
          setValue={setValue}
          initialDateOption={dateOptions.OTHER}
          categories={categories}
          isCategorySelected={isCategorySelected}
        />
        <Flexbox marginTop={8} gap={7} justifyContent="flex-start">
          <GroupuiButton role="button" type="submit" disabled={updateItem.isLoading} icon="save-24">Save</GroupuiButton>
          <GroupuiButton role="button" variant="secondary" icon="trash-24" onClick={openDeleteModal}>Delete</GroupuiButton>
        </Flexbox>
      </form>
    </>
  );
};

export default EditItem;
