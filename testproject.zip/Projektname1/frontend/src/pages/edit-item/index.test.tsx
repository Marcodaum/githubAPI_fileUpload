import React from 'react';
import { fireEvent, waitFor } from '@testing-library/react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { Route, Routes } from 'react-router-dom';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import { groupuiChange, render, screen } from '../../test/utils';
import * as useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import * as useNotificationContext from '../../hooks/contexts/use-notification-context';
import EditItem from './index';

jest.mock('../../hooks/contexts/use-board-id-context');
jest.mock('../../hooks/contexts/use-notification-context');

const mockUseBoardIdContext = useBoardIdContext.default as jest.Mock;
const mockUseNotificationContext = useNotificationContext.default as jest.Mock;

const placeholders = {
  TITLE: 'Title',
  DESCRIPTION: 'Description',
  AUTHOR: 'Author',
  LINK: 'Paste your link here',
  IMAGE: 'Image',
  DATEPICKER: 'The item will be displayed in the standup board between this dates.',
};

const server = setupServer();

describe('Edit item page', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => server.resetHandlers());
  beforeEach(() => {
    jest.mocked(mockUseBoardIdContext).mockReturnValue('board-id');
    jest.mocked(mockUseNotificationContext).mockReturnValue({ setNotification: () => {} });
  });

  it('renders the board details and item values', async () => {
    jest.useFakeTimers({ now: new Date(2022, 3, 25) });

    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => {
        if (req.url.searchParams.get('from_date') === '2022-04-25') {
          return res(ctx.json({
            id: 'board-id',
            name: 'Hawaii SDC',
            categories: [
              {
                id: 'category-1',
                name: 'New Faces',
                description: 'New specimens in the office',
              },
              {
                id: 'category-2',
                name: 'Helps and Offers',
                description: 'Help me!',
              },
            ],
            items: [
              {
                id: 'item-id',
                title: 'title',
                description: 'description',
                author: 'author',
                link: 'link',
                startDate: '2023-05-25',
                endDate: '2023-05-26',
                category: 'category-1',
              },
            ],
          }));
        }
        return res(ctx.status(400));
      }),
    );

    render(
      <Routes>
        <Route path="/" element="mock-board-page" />
        <Route path="/edit-item/:itemId" element={<EditItem />} />
      </Routes>,
      '/edit-item/item-id',
    );

    expect(await screen.findByText('Edit Item')).toBeVisible();
    expect(screen.getByText('Choose the category')).toBeVisible();
    expect(screen.getByText('When will the item be presented?')).toBeVisible();
    expect(screen.getByText('The item will be displayed in the standup board on this date.')).toBeVisible();

    expect(await screen.findByText('Hawaii SDC')).toBeVisible();
    expect(screen.getByText('New Faces')).toBeVisible();
    expect(screen.getByText('New specimens in the office')).toBeVisible();
    expect(screen.getByText('Helps and Offers')).toBeVisible();
    expect(screen.getByText('Help me!')).toBeVisible();
    expect(screen.getByText('Global')).toBeVisible();
    expect(screen.getByText('Items that are shared in all office standups')).toBeVisible();

    expect(screen.getByPlaceholderText(placeholders.DATEPICKER)).toHaveValue('2023-05-25:2023-05-26');
    expect(screen.getByText('Pick a date').parentNode).toHaveAttribute('checked', 'true');
    expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title');
    expect(screen.getByPlaceholderText(placeholders.DESCRIPTION)).toHaveValue('description');
    expect(screen.getByPlaceholderText(placeholders.AUTHOR)).toHaveValue('author');
    expect(screen.getByPlaceholderText(placeholders.LINK)).toHaveValue('link');

    fireEvent.click(screen.getByRole('link', { name: 'Hawaii SDC' }));
    expect(screen.getByText('mock-board-page')).toBeVisible();
  });

  it('throws an error when the item does not exist', async () => {
    // @ts-ignore
    // eslint-disable-next-line no-console
    console.error.mockImplementation(() => null);

    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({
          id: 'board-id',
          categories: [],
          items: [],
        }))
      )),
    );

    const mockOnError = jest.fn();
    render(
      <Routes>
        <Route
          path="/edit-item/:itemId"
          element={(
            <ReactErrorBoundary FallbackComponent={() => <>Error</>} onError={mockOnError}>
              <EditItem />
            </ReactErrorBoundary>
        )}
        />
      </Routes>,
      '/edit-item/item-id',
    );

    expect(await screen.findByText('Error')).toBeVisible();
    expect(mockOnError).toHaveBeenCalledWith(new Error('Item not found'), expect.any(Object));
  });

  describe('saving', () => {
    let requestData: any;
    beforeEach(() => {
      requestData = undefined;
      server.use(
        rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
          res(ctx.json({
            id: 'board-id',
            categories: [
              {
                id: 'category-1',
                name: 'Category 1',
              },
            ],
            items: [
              {
                id: 'item-id',
                title: 'title',
                description: 'description',
                author: 'author',
                link: 'link',
                startDate: '2023-05-25',
                endDate: '2023-05-26',
                images: ['some_url'],
                category: 'global',
              },
            ],
          }))
        )),
        rest.put(`${process.env.API_URL}/boards/board-id/items/item-id`, async (req, res, ctx) => {
          requestData = await req.json();
          return res(ctx.status(200));
        }),
        rest.delete(`${process.env.API_URL}/boards/board-id/items/item-id`, (req, res, ctx) => {
          requestData = null;
          return res(ctx.status(200));
        }),
      );
    });

    it('saves the same values if nothing changes', async () => {
      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/edit-item/:itemId" element={<EditItem />} />
        </Routes>,
        '/edit-item/item-id',
      );

      await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));
      expect(mockSetNotification).not.toHaveBeenCalled();

      const button = screen.getByRole('button', { name: 'Save' });
      fireEvent.submit(button);

      await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
      await waitFor(() => expect(requestData).toEqual({
        title: 'title',
        description: 'description',
        author: 'author',
        link: 'link',
        startDate: '2023-05-25',
        endDate: '2023-05-26',
        images: ['some_url'], // since update doesn't change it
        category: 'global',
      }));
      await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('success', 'Item successfully updated!'));
      expect(await screen.findByText('mock-board-page')).toBeVisible();
    });

    it('saves the new values for today', async () => {
      jest.useFakeTimers({ now: new Date(2022, 3, 25) });

      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/edit-item/:itemId" element={<EditItem />} />
        </Routes>,
        '/edit-item/item-id',
      );

      await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));

      fireEvent.click(await screen.findByText('Category 1'));
      groupuiChange(screen.getByPlaceholderText(placeholders.TITLE), 'new-title');
      groupuiChange(screen.getByPlaceholderText(placeholders.DESCRIPTION), 'new-description');
      groupuiChange(screen.getByPlaceholderText(placeholders.AUTHOR), 'new-author');
      groupuiChange(screen.getByPlaceholderText(placeholders.LINK), 'new-link');
      fireEvent.click(screen.getByText('Today'));

      expect(mockSetNotification).not.toHaveBeenCalled();

      const button = screen.getByRole('button', { name: 'Save' });
      fireEvent.submit(button);

      await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
      await waitFor(() => expect(requestData).toEqual({
        title: 'new-title',
        description: 'new-description',
        author: 'new-author',
        link: 'new-link',
        startDate: '2022-04-25',
        endDate: '2022-04-25',
        images: ['some_url'], // since update doesn't change it
        category: 'category-1',
      }));
      await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('success', 'Item successfully updated!'));
      expect(await screen.findByText('mock-board-page')).toBeVisible();
    });

    it('calls setNotification with an error when failing to update', async () => {
      // @ts-ignore
      // eslint-disable-next-line no-console
      console.error.mockImplementation(() => null);
      server.use(
        rest.put(`${process.env.API_URL}/boards/board-id/items/item-id`, (req, res, ctx) => (
          res(ctx.status(500))
        )),
      );

      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/edit-item/:itemId" element={<EditItem />} />
        </Routes>,
        '/edit-item/item-id',
      );

      await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));
      expect(mockSetNotification).not.toHaveBeenCalled();

      const button = screen.getByRole('button', { name: 'Save' });
      fireEvent.submit(button);

      await waitFor(() => expect(button).toHaveAttribute('disabled', 'true'));
      await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('danger', 'Oops! There has been error trying to update the item.'));
      expect(button).toHaveAttribute('disabled', 'false');
      expect(screen.getByText('Edit Item')).toBeVisible();
      expect(screen.queryByText('mock-board-page')).not.toBeInTheDocument();
    });

    it('deletes item', async () => {
      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/edit-item/:itemId" element={<EditItem />} />
        </Routes>,
        '/edit-item/item-id',
      );

      await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));
      expect(mockSetNotification).not.toHaveBeenCalled();

      const deleteButton = screen.getByRole('button', { name: 'Delete' });
      fireEvent.click(deleteButton);

      expect(screen.queryByText('The item will be ejected to space, are you sure about that?')).toBeInTheDocument();

      const confirmButton = screen.getByRole('button', { name: 'Confirm' });
      fireEvent.click(confirmButton);

      await waitFor(() => expect(mockSetNotification).toHaveBeenCalledWith('success', 'Item successfully deleted!'));
      await waitFor(() => expect(requestData).toBeFalsy());
    });

    it('cancels deletion', async () => {
      const mockSetNotification = jest.fn();
      jest.mocked(mockUseNotificationContext).mockReturnValue({
        setNotification: mockSetNotification,
      });

      render(
        <Routes>
          <Route path="/" element="mock-board-page" />
          <Route path="/edit-item/:itemId" element={<EditItem />} />
        </Routes>,
        '/edit-item/item-id',
      );

      await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));
      expect(mockSetNotification).not.toHaveBeenCalled();

      const deleteButton = screen.getByRole('button', { name: 'Delete' });
      fireEvent.click(deleteButton);

      expect(screen.queryByText('The item will be ejected to space, are you sure about that?')).toBeInTheDocument();

      const cancelButton = screen.getByRole('button', { name: 'Cancel' });
      fireEvent.click(cancelButton);

      expect(screen.queryByText('The item will be ejected to space, are you sure about that?')).not.toBeInTheDocument();
    });
  });

  it('shows a validation error for required fields', async () => {
    server.use(
      rest.get(`${process.env.API_URL}/boards/board-id`, (req, res, ctx) => (
        res(ctx.json({
          id: 'board-id',
          categories: [],
          items: [
            {
              id: 'item-id',
              title: 'title',
              author: 'author',
              startDate: '2023-05-25',
              endDate: '2023-05-26',
              category: 'global',
            },
          ],
        }))
      )),
    );

    render(
      <Routes>
        <Route path="/edit-item/:itemId" element={<EditItem />} />
      </Routes>,
      '/edit-item/item-id',
    );

    await waitFor(() => expect(screen.getByPlaceholderText(placeholders.TITLE)).toHaveValue('title'));

    expect(screen.queryByText('Title is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Author is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Date from is required')).not.toBeInTheDocument();
    expect(screen.queryByText('Date to is required')).not.toBeInTheDocument();

    groupuiChange(screen.getByPlaceholderText(placeholders.TITLE), '');
    groupuiChange(screen.getByPlaceholderText(placeholders.AUTHOR), '');
    groupuiChange(screen.getByPlaceholderText(placeholders.DATEPICKER), '');

    fireEvent.submit(screen.getByRole('button', { name: 'Save' }));

    expect(await screen.findByText('Title is required')).toBeVisible();
    expect(screen.getByText('Author is required')).toBeVisible();
  });
});
