import styled from 'styled-components';
import {
  GroupuiDivider, GroupuiGridCol, GroupuiGridRow,
} from '@group-ui/group-ui-react';
import React from 'react';
import BoardItem from './board-item';
import useBoard from '../../hooks/queries/use-board';
import useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import Container from '../styled/container';
import { Grey500Text } from '../styled/grey-text';

const StyledGroupuiRow = styled(GroupuiGridRow)`
  margin-left: calc(-1 * var(--groupui-spacing-3));
  margin-right: calc(-1 * var(--groupui-spacing-3));
  width: auto;

  @media (min-width: 560px) {
    margin-left: calc(-1 * var(--groupui-spacing-4));
    margin-right: calc(-1 * var(--groupui-spacing-4));
  }
`;

const StyledGridCol = styled(GroupuiGridCol)`
    padding-bottom: 20px;
`;

const BoardItemList = () => {
  const boardId = useBoardIdContext();
  const { board, hasLoaded } = useBoard(boardId);

  if (!hasLoaded) return null;

  if (board.items.length === 0) {
    return (
      <>
        <Container marginTop={10}>
          <GroupuiDivider />
        </Container>
        <Container textAlign="center" marginTop={10}>
          <Grey500Text>There are no current or upcoming standup items</Grey500Text>
        </Container>
      </>
    );
  }

  return (
    <Container marginTop={10}>
      <StyledGroupuiRow marginType="custom" marginS="0" marginM="0" marginL="0" marginXl="0" marginXxl="0">
        {board.items.map((item) => (
          <StyledGridCol key={item.id} s={12} m={6} l={4}>
            <BoardItem item={item} />
          </StyledGridCol>
        ))}
      </StyledGroupuiRow>
    </Container>
  );
};

export default BoardItemList;
