import React, { FC, ReactElement } from 'react';
import { parse, format } from 'date-fns';
import { GroupuiTag } from '@group-ui/group-ui-react';
import styled from 'styled-components';

interface BoardItemDateProps {
  startDate: string,
  endDate: string
}

const StyledTag = styled(GroupuiTag)`
  text-transform: uppercase;
  margin: var(--groupui-spacing-3) 0;
`;

const BoardItemDate: FC<BoardItemDateProps> = ({ startDate, endDate }): ReactElement => {
  const start = parse(startDate, 'yyyy-MM-dd', new Date());
  const end = parse(endDate, 'yyyy-MM-dd', new Date());

  const endString = format(end, 'iii dd MMM');
  const startString = format(start, start.getMonth() !== end.getMonth() ? 'iii dd MMM' : 'iii dd');

  const dateString = startDate.valueOf() === endDate.valueOf() ? endString : `${startString} - ${endString}`;

  return (
    <StyledTag variant="secondary">
      {dateString}
    </StyledTag>
  );
};

export default BoardItemDate;
