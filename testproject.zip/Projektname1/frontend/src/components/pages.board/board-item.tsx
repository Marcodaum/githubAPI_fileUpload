import React, { FC, ReactElement } from 'react';
import {
  GroupuiCard, GroupuiHeadline, GroupuiTag, GroupuiText,
} from '@group-ui/group-ui-react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import BoardItemModel from '../../models/board-item';
import BoardItemDate from './board-item-date';
import { Grey500Text } from '../styled/grey-text';
import { White700Text } from '../styled/white-text';

interface BoardItemProps {
    item: BoardItemModel
}

const StyledCard = styled(GroupuiCard)`
  text-align: center;
  height: 100%;
`;

const StyledDescription = styled(GroupuiText)`
  margin-top: var(--groupui-spacing-2);
  display: -webkit-box;
  line-clamp: 3;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

const StyledTag = styled(GroupuiTag)`
  background-color: var(--groupui-vwag-color-grey-600);
`;

const BoardItem: FC<BoardItemProps> = ({ item }): ReactElement => {
  const navigate = useNavigate();

  return (
    <StyledCard interactive onClick={() => navigate(`/edit-item/${item.id}`)}>
      <GroupuiHeadline heading="h4">{item.title}</GroupuiHeadline>
      <BoardItemDate startDate={item.startDate} endDate={item.endDate} />
      <Grey500Text size="caption">{item.author}</Grey500Text>
      <StyledDescription size="body-2">{item.description}</StyledDescription>
      { (item.images && (item.images.length > 0))
        && <StyledTag><White700Text size="label">Image Uploaded</White700Text></StyledTag> }
    </StyledCard>
  );
};

export default BoardItem;
