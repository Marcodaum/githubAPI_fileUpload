import React, { FC, ReactElement } from 'react';
import {
  GroupuiCard, GroupuiText,
} from '@group-ui/group-ui-react';
import { UseFormWatch } from 'react-hook-form';
import styled from 'styled-components';
import StyledGroupuiRow from '../styled/grid-row';
import StyledGridCol from '../styled/grid-col';
import Category from '../../models/category';
import Container from '../styled/container';

interface InputProps {
  watch: UseFormWatch<any>,
  categories: Category[],
  setCategory: (category: string) => void,
  isCategorySelected: boolean
}

interface StyledCardProps {
  border?: string;
}

const StyledText = styled(GroupuiText)`
  padding-bottom: 15px;
  font-weight: bold;
`;

const StyledErrorText = styled(GroupuiText)`
  color: var(--groupui-vwag-color-signal-red-800-primary);
`;

const StyledCard = styled(GroupuiCard)<StyledCardProps>`
  border: ${({ border }) => border || 'none'};
  height: 100%;
  cursor: pointer;
`;

const CategorySelector: FC<InputProps> = ({
  watch, setCategory, categories, isCategorySelected,
}): ReactElement => {
  const selectedCategory = watch('category');

  return (
    <Container marginTop={5}>
      <StyledGroupuiRow marginType="custom" marginS="0" marginM="0" marginL="0" marginXl="0" marginXxl="0">
        {categories.map((category) => (
          <StyledGridCol key={category.id} s={12} m={6} l={4}>
            <StyledCard
              // TODO: replace color hex with groupui color var
              border={selectedCategory === category.id ? '2px solid #20607E' : 'none'}
              elevation="1"
              data-testid="radio-group-category"
              onClick={() => setCategory(category.id)}
            >
              <StyledText>
                {category.name}
              </StyledText>
              <GroupuiText>
                {category.description}
              </GroupuiText>
            </StyledCard>
          </StyledGridCol>
        ))}
      </StyledGroupuiRow>
      {!isCategorySelected && <StyledErrorText size="body-2">Category is required</StyledErrorText>}
    </Container>
  );
};
export default CategorySelector;
