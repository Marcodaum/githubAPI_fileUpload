import React, { FC, ReactElement, useState } from 'react';
import {
  GroupuiButtonGroup, GroupuiButtonGroupButton, GroupuiDatePickerNew, GroupuiIcon,
} from '@group-ui/group-ui-react';
import { addDays, format } from 'date-fns';
import { UseFormWatch } from 'react-hook-form';
import styled from 'styled-components';
import Container from '../styled/container';
import { dateOptions } from '../../utils/constants';
import { today } from '../../utils/dates';

interface InputProps {
  watch: UseFormWatch<any>,
  setDate: (from: string, to: string) => void,
  initialOption: number,
}

const StyledDatePickerButton = styled.div`
  display: flex;
  align-items: center;
  gap: var(--groupui-spacing-3);
`;

const DateSelector: FC<InputProps> = ({
  setDate, initialOption, watch,
}): ReactElement => {
  const [selection, setSelection] = useState(initialOption);
  const startDate = watch('startDate');
  const endDate = watch('endDate');

  const dates = `${startDate}:${endDate}`;

  const onToday = () => {
    setSelection(dateOptions.TODAY);
    setDate(today(), today());
  };

  const onTomorrow = () => {
    setSelection(dateOptions.TOMORROW);
    const date = format(addDays(new Date(), 1), 'yyyy-MM-dd');
    setDate(date, date);
  };

  const handleDateChange = (event: CustomEvent<HTMLInputElement>) => {
    // @ts-ignore
    const date = event?.target?.value;

    if (date && date.includes(':')) {
      const from = date.split(':')[0];
      const to = date.split(':')[1];

      setDate(from, to);
    }
  };

  return (
    <>
      <GroupuiButtonGroup variant="radio">
        <GroupuiButtonGroupButton
          onClick={onToday}
          checked={selection === dateOptions.TODAY}
        >
          Today
        </GroupuiButtonGroupButton>
        <GroupuiButtonGroupButton
          onClick={onTomorrow}
          checked={selection === dateOptions.TOMORROW}
        >
          Tomorrow
        </GroupuiButtonGroupButton>
        <GroupuiButtonGroupButton
          onClick={() => setSelection(dateOptions.OTHER)}
          checked={selection === dateOptions.OTHER}
        >
          <StyledDatePickerButton>
            Pick a date
            <GroupuiIcon
              name="calendar-16"
              theme="vwag"
            />
          </StyledDatePickerButton>
        </GroupuiButtonGroupButton>
      </GroupuiButtonGroup>
      {selection === dateOptions.OTHER && (
        <Container maxWidth="540px" marginTop={3}>
          <GroupuiDatePickerNew
            severity="none"
            dateFormat="Y-m-d"
            minDate={today()}
            placeholder="The item will be displayed in the standup board between this dates."
            rangeMode
            rangeSeparator=" to "
            required
            value={dates || today()}
            onGroupuiChange={(e) => handleDateChange(e)}
          />
        </Container>
      )}
    </>
  );
};

export default DateSelector;
