import { GroupuiText } from '@group-ui/group-ui-react';
import React, { FC } from 'react';
import { Control, UseFormSetValue, UseFormWatch } from 'react-hook-form';
import styled from 'styled-components';
import Container from '../styled/container';
import CategorySelector from './category-selector';
import DateSelector from './date-selector';
import Category from '../../models/category';
import TextInput from '../form/text-input';

interface ItemFieldsProps {
  watch: UseFormWatch<any>,
  control: Control<any>,
  setValue: UseFormSetValue<any>,
  initialDateOption: number,
  categories: Category[],
  isCategorySelected: boolean
}

const StyledText = styled(GroupuiText)`
  color:  var(--groupui-vwag-color-grey-800-primary);
`;

const ItemFields: FC<ItemFieldsProps> = ({
  watch, control, setValue, initialDateOption, categories, isCategorySelected,
}) => {
  const setDate = (from: string, to: string) => {
    setValue('startDate', from, { shouldValidate: true });
    setValue('endDate', to, { shouldValidate: true });
  };
  const setCategory = (category: string) => {
    setValue('category', category, { shouldValidate: true });
  };

  return (
    <>
      <Container marginTop={8}>
        <GroupuiText size="body-1" weight="bold">Choose the category</GroupuiText>
        <CategorySelector
          watch={watch}
          setCategory={setCategory}
          categories={categories}
          isCategorySelected={isCategorySelected}
        />
      </Container>
      <Container marginTop={7}>
        <Container marginBottom={7}>
          <GroupuiText size="body-1" weight="bold">When will the item be presented?</GroupuiText>
          <StyledText size="body-1">The item will be displayed in the standup board on this date.</StyledText>
        </Container>
        <DateSelector
          setDate={setDate}
          initialOption={initialDateOption}
          watch={watch}
        />
      </Container>
      <Container marginTop={11}>
        <TextInput
          label="Title"
          control={control}
          name="title"
          placeholder="Title"
          required
        />
        <TextInput
          label="Author"
          control={control}
          name="author"
          placeholder="Author"
          required
        />
        <TextInput
          label="Link"
          control={control}
          name="link"
          placeholder="Paste your link here"
        />
        <TextInput
          label="Description"
          control={control}
          name="description"
          placeholder="Description"
        />
      </Container>
    </>
  );
};

export default ItemFields;
