import React from 'react';
import { GroupuiHeader } from '@group-ui/group-ui-react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import { WhiteIcon, WhiteHeadline } from '../styled/white-text';
import Flexbox from '../styled/flexbox';

const StyledLink = styled(Link)`
  &:focus, &:hover, &:visited, &:link, &:active {
    text-decoration: none;
  }
`;

const StyledHeader = styled(GroupuiHeader)`
  flex: 0 0 auto;
`;

const Header = () => (
  <StyledHeader>
    <StyledLink to="/boards">
      <Flexbox gap={4}>
        <WhiteIcon name="rocket-32" />
        <WhiteHeadline heading="h6" weight="bold">Standup Boards</WhiteHeadline>
      </Flexbox>
    </StyledLink>
  </StyledHeader>
);

export default Header;
