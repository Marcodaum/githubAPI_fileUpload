import React from 'react';
import { render, screen } from '../../../test/utils';
import ErrorBoundary from './index';

describe('Error boundary', () => {
  it('renders the children if no error', () => {
    render(<ErrorBoundary><div>happy-children</div></ErrorBoundary>);

    expect(screen.getByText('happy-children')).toBeVisible();
    expect(screen.queryByText('Oops! Something went wrong.')).not.toBeInTheDocument();
  });

  it('shows an error message if error', () => {
    // @ts-ignore
    // eslint-disable-next-line no-console
    console.error.mockImplementation(() => null);

    const MockErrorElement = () => {
      throw new Error('dummy error');
    };

    render(
      <ErrorBoundary>
        <div>happy-children</div>
        <MockErrorElement />
      </ErrorBoundary>,
    );

    expect(screen.getByText('Oops! Something went wrong.')).toBeVisible();
    expect(screen.getByText('Something went wrong. Please try again.')).toBeVisible();
    expect(screen.queryByText('happy-children')).not.toBeInTheDocument();
  });
});
