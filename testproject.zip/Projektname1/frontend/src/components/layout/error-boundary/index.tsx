import { GroupuiHeadline, GroupuiText } from '@group-ui/group-ui-react';
import React, { FC } from 'react';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import Container from '../../styled/container';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

const ErrorPage = () => (
  <Container textAlign="center" marginTop={12} marginBottom={6}>
    <GroupuiHeadline>Oops! Something went wrong.</GroupuiHeadline>
    <GroupuiText>Something went wrong. Please try again.</GroupuiText>
  </Container>
);

const ErrorBoundary: FC<ErrorBoundaryProps> = ({ children }) => (
  <ReactErrorBoundary FallbackComponent={ErrorPage}>
    {children}
  </ReactErrorBoundary>
);

export default ErrorBoundary;
