import React, { useMemo, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { GroupuiNotification } from '@group-ui/group-ui-react';
import Header from './header';
import { NotificationContext, NotificationContextType } from '../../hooks/contexts/use-notification-context';
import NotificationType from '../../models/notification-type';
import ErrorBoundary from './error-boundary';

const StyledBody = styled.main`
  position: relative;
  display: flex;
  flex: 1 0 auto;
  overflow: hidden;
  background-color: var(--groupui-vwag-color-white);
`;

const StyledPage = styled.div`
  box-sizing: border-box;
  width: 100%;
  max-width: 100%;
  margin: 28px 112px 132px 112px;
  padding: 0 var(--groupui-spacing-7);
`;

const StyledContent = styled.div`
  max-width: 100%;
  padding: 0 4px;
  height: 100%;
`;

const StyledNotification = styled(GroupuiNotification)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 99;
`;

const AppLayout = () => {
  const location = useLocation();
  const path = location.pathname.split('/')[1];
  const [notificationMessage, setNotificationMessage] = useState('');
  const [notificationType, setNotificationType] = useState(NotificationType.Default);

  const context: NotificationContextType = useMemo(() => ({
    setNotification: (type: NotificationType, message: string) => {
      setNotificationMessage(message);
      setNotificationType(type);
    },
  }), []);

  return (
    <>
      {notificationMessage && (
        <StyledNotification
          severity={notificationType}
          onGroupuiClose={() => setNotificationMessage('')}
          autoDismiss={5000}
          dismissible
        >
          {notificationMessage}
        </StyledNotification>
      )}
      {path !== 'present' && <Header />}
      <StyledBody>
        <StyledPage>
          <StyledContent>
            <NotificationContext.Provider value={context}>
              <ErrorBoundary>
                <Outlet />
              </ErrorBoundary>
            </NotificationContext.Provider>
          </StyledContent>
        </StyledPage>
      </StyledBody>
    </>
  );
};

export default AppLayout;
