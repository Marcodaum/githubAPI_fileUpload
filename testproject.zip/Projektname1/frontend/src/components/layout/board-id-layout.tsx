import React, { FC } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { BoardIdContext } from '../../hooks/contexts/use-board-id-context';

const BoardIdLayout: FC<{ boardId: string | undefined }> = ({ boardId }) => {
  if (!boardId) {
    return <Navigate to="/boards" />;
  }

  return (
    <BoardIdContext.Provider value={boardId}>
      <Outlet />
    </BoardIdContext.Provider>
  );
};

export default BoardIdLayout;
