import React, { FC } from 'react';
import { Outlet } from 'react-router-dom';
import { GroupuiLoadingSpinner } from '@group-ui/group-ui-react';
import useStandup from '../../hooks/queries/use-standup';
import useBoardIdContext from '../../hooks/contexts/use-board-id-context';
import { StandupContext } from '../../hooks/contexts/use-standup-context';
import { today } from '../../utils/dates';

const PresentationLayout: FC = () => {
  const boardId = useBoardIdContext();
  const { data: standup, isLoading } = useStandup(boardId, today());

  if (isLoading) {
    return <GroupuiLoadingSpinner displayed background="transparent" />;
  }

  return (
    <StandupContext.Provider value={standup!}>
      <Outlet />
    </StandupContext.Provider>
  );
};

export default PresentationLayout;
