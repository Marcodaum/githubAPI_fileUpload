import React, { FC } from 'react';
import { GroupuiIcon, GroupuiText } from '@group-ui/group-ui-react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import Flexbox from '../styled/flexbox';

const StyledLink = styled(Link)`
    display: inline-block;
    margin-bottom: var(--groupui-spacing-5);
  
    groupui-icon {
      margin-left: -5px;
    }
    
    groupui-text {
        position: relative;
        
        &:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 1px;
            width: 0;
            height: 1px;
            background-color: var(--groupui-vwag-color-petrol-800-primary);
            transition: width 300ms ease;
        }
    }
    
    &:hover groupui-text:after,
    &:focus groupui-text:after {
        width: 100%;
    }
`;

const StyledBlueText = styled(GroupuiText)`
  color: var(--groupui-vwag-color-petrol-800-primary);
`;

export interface BreadcrumbProps {
  label: string,
  url: string,
}

const Breadcrumb: FC<BreadcrumbProps> = ({ label, url }) => (
  <StyledLink to={url}>
    <Flexbox gap={3} alignItems="center">
      <GroupuiIcon name="chevron-left-24" />
      <StyledBlueText weight="bold">{label}</StyledBlueText>
    </Flexbox>
  </StyledLink>
);

export default Breadcrumb;
