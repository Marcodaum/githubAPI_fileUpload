import React, { FC, ReactElement } from 'react';
import { Control, Controller } from 'react-hook-form';
import { GroupuiInput } from '@group-ui/group-ui-react';

const requiredRule = (fieldName: string) => ({ value: true, message: `${fieldName} is required` });

const defaultProps = {
  required: false,
  rules: {},
};

interface InputProps {
  name: string,
  control: Control<any>,
  placeholder: string,
  label: string,
  required?: boolean,
  rules?: object,
}

const TextInput: FC<InputProps> = ({
  name, control, placeholder, label, required, rules,
}): ReactElement => (
  <Controller
    name={name}
    control={control}
    rules={{
      ...rules,
      required: required ? requiredRule(label) : undefined,
    }}
    render={({ field, fieldState: { error } }) => (
      <GroupuiInput
        ref={field.ref}
        value={field.value}
        name={field.name}
        onGroupuiChange={field.onChange}
        placeholder={placeholder}
        severity={error ? 'danger' : undefined}
      >
        <span slot="label">
          {`${label}${required ? ' *' : ''}`}
        </span>
        {error && <span slot="description">{error.message}</span>}
      </GroupuiInput>
    )}
  />
);

TextInput.defaultProps = defaultProps;

export default TextInput;
