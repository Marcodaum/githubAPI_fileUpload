import { GroupuiButton } from '@group-ui/group-ui-react';
import React, {
  ChangeEvent, FC, ReactElement, useState,
} from 'react';
import { UseFormRegister } from 'react-hook-form';
import styled from 'styled-components';
import Flexbox from '../styled/flexbox';

const defaultProps = {
  required: false,
};

interface InputProps {
  name: string,
  register: UseFormRegister<any>,
  label: string,
  required?: boolean,
}

interface FilePreview {
  name: string,
  preview: string,
}

const StyledInput = styled.input`
  display: none;
`;

const StyledLabel = styled.label`
  cursor: pointer;
`;

// TODO: display label
// TODO: handle file type, file size and required validation
const ImageInput: FC<InputProps> = ({ name, register }): ReactElement => {
  const [uploads, setUploads] = useState<FilePreview[]>([]);

  const { onChange, onBlur, ref } = register(name);

  const handleUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files ? Array.from(event.target.files).map((file) => ({
      name: file.name,
      preview: URL.createObjectURL(file),
    })) : [];

    setUploads(files);
    return onChange(event);
  };

  return (
    <div>
      <GroupuiButton variant="secondary">
        <StyledLabel htmlFor={`${name}-upload`}>
          <StyledInput
            type="file"
            ref={ref}
            onChange={handleUpload}
            onBlur={onBlur}
            id={`${name}-upload`}
            name={name}
            accept="image/png, image/jpeg, image/gif"
            multiple
          />
          Upload
        </StyledLabel>
      </GroupuiButton>
      <Flexbox gap={3} justifyContent="flex-start">
        {uploads.map((upload) => <img key={upload.name} src={upload.preview} alt={upload.name} height="100px" />)}
      </Flexbox>
    </div>
  );
};

ImageInput.defaultProps = defaultProps;

export default ImageInput;
