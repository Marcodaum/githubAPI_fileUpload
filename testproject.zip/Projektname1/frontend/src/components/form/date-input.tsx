import React, { FC, ReactElement } from 'react';
import { Control } from 'react-hook-form';
import TextInput from './text-input';

const defaultProps = {
  required: false,
  rules: {},
};

interface InputProps {
  name: string,
  control: Control<any>,
  placeholder: string,
  label: string,
  required?: boolean,
  rules?: object,
}

const DateInput: FC<InputProps> = ({
  name, control, placeholder, label, required, rules,
}): ReactElement => (
  <TextInput
    name={name}
    control={control}
    placeholder={placeholder}
    label={label}
    rules={{
      ...rules,
      pattern: {
        value: /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/,
        message: `${label} is invalid, enter a date with the expected format yyyy-mm-dd (e.g. 2022-02-22)`,
      },
    }}
    required={required}
  />
);

DateInput.defaultProps = defaultProps;

export default DateInput;
