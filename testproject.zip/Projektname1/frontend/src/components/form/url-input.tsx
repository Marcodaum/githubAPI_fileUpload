import React, { FC, ReactElement } from 'react';
import { Control } from 'react-hook-form';
import TextInput from './text-input';

const defaultProps = {
  required: false,
};

interface InputProps {
  name: string,
  control: Control<any>,
  placeholder: string,
  label: string,
  required?: boolean,
}

const UrlInput: FC<InputProps> = ({
  name, control, placeholder, label, required,
}): ReactElement => (
  <TextInput
    name={name}
    control={control}
    placeholder={placeholder}
    label={label}
    rules={{
      validate: (value: string) => {
        try {
          new URL(value);
        } catch (_) {
          return `${label} is an invalid URL`;
        }
        return true;
      },
    }}
    required={required}
  />
);

UrlInput.defaultProps = defaultProps;

export default UrlInput;
