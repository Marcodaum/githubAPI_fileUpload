import React, { FC, ReactElement } from 'react';
import { Control, Controller } from 'react-hook-form';
import { GroupuiRadioButton, GroupuiRadioGroup } from '@group-ui/group-ui-react';
import styled from 'styled-components';

const StyledSmall = styled.small`
  display: block;
`;

interface RadioOption {
  value: string,
  label: string,
  description?: string,
}

interface InputProps {
  name: string,
  control: Control<any>,
  options: RadioOption[],
}

const RadioGroupInput: FC<InputProps> = ({
  name, control, options,
}): ReactElement => (
  <Controller
    name={name}
    control={control}
    render={({ field }) => (
      <GroupuiRadioGroup
        data-testid={`radio-group-${name}`}
        ref={field.ref}
        value={field.value}
        name={field.name}
        onGroupuiChange={field.onChange}
      >
        {options.map((option) => (
          <GroupuiRadioButton key={option.value} value={option.value}>
            {option.label}
            {option.description && <StyledSmall>{option.description}</StyledSmall>}
          </GroupuiRadioButton>
        ))}
      </GroupuiRadioGroup>
    )}
  />
);
export default RadioGroupInput;
