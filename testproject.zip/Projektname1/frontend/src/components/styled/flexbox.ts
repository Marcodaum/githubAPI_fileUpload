import styled from 'styled-components';
import { groupuiSpacing } from './container';

interface Props {
  alignItems?: string;
  justifyContent?: string;
  wrap?: string;
  gap?: number;
  padding?: number;
  marginTop?: number,
  marginRight?: number | 'auto',
  marginBottom?: number,
  marginLeft?: number | 'auto',
  direction?: string;
  height?: string;
}

const Flexbox = styled.div<Props>`
  display: flex;
  align-items: ${({ alignItems }) => alignItems || 'center'};
  justify-content: ${({ justifyContent }) => justifyContent || 'space-between'};
  gap: ${({ gap }) => (gap ? `var(--groupui-spacing-${gap})` : '0')};
  padding: ${({ padding }) => (padding ? `var(--groupui-spacing-${padding})` : '0')};
  flex-wrap: ${({ wrap }) => wrap || 'nowrap'};
  margin: ${(props) => `
    ${groupuiSpacing(props.marginTop)} 
    ${groupuiSpacing(props.marginRight)} 
    ${groupuiSpacing(props.marginBottom)} 
    ${groupuiSpacing(props.marginLeft)}
  `};
  flex-direction: ${({ direction }) => direction || 'row'};
  height: ${({ height }) => height || 'auto'};
`;

export default Flexbox;
