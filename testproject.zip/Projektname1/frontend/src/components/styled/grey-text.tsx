import styled from 'styled-components';
import { GroupuiHeadline, GroupuiText } from '@group-ui/group-ui-react';

const Grey300Text = styled(GroupuiText)`
  color: var(--groupui-vwag-color-grey-300);
`;

const Grey500Text = styled(GroupuiText)`
  color: var(--groupui-vwag-color-grey-500);
`;

const Grey700Text = styled(GroupuiText)`
  color: var(--groupui-vwag-color-grey-700-primary);
`;

const Grey1000Text = styled(GroupuiText)`
  color: var(--groupui-vwag-color-grey-1000);
`;

const Grey1000Headline = styled(GroupuiHeadline)`
  color: var(--groupui-vwag-color-grey-1000);
`;

export {
  Grey300Text, Grey500Text, Grey700Text, Grey1000Text, Grey1000Headline,
};
