import styled from 'styled-components';

interface ContainerProps {
  maxWidth?: string,
  textAlign?: string,
  marginTop?: number,
  marginRight?: number | 'auto',
  marginBottom?: number,
  marginLeft?: number | 'auto',
}

export const groupuiSpacing = (spacing: number | string | undefined) => {
  if (!spacing) return 0;
  if (spacing === 'auto') return 'auto';
  if (typeof spacing === 'number' && spacing > 0 && spacing <= 13) return `var(--groupui-spacing-${spacing})`;
  return `${spacing}px`;
};

const Container = styled.div<ContainerProps>`
  max-width: ${({ maxWidth }) => maxWidth || 'none'};
  text-align: ${({ textAlign }) => textAlign || 'inherit'};
  margin: ${(props) => `
    ${groupuiSpacing(props.marginTop)} 
    ${groupuiSpacing(props.marginRight)} 
    ${groupuiSpacing(props.marginBottom)} 
    ${groupuiSpacing(props.marginLeft)}
  `};
`;

export default Container;
