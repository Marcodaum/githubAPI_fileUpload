import styled from 'styled-components';
import { GroupuiText} from '@group-ui/group-ui-react';

interface Props {
}

const CountdownText = styled(GroupuiText)<Props>`
    font-size: 180px;
    font-weight: 700;
    line-height: 234px;
`;

export default CountdownText;
