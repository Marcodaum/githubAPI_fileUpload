import { GroupuiGridRow } from '@group-ui/group-ui-react';
import styled from 'styled-components';

const StyledGroupuiRow = styled(GroupuiGridRow)`
  margin-left: calc(-1 * var(--groupui-spacing-3));
  margin-right: calc(-1 * var(--groupui-spacing-3));
  width: auto;

  @media (min-width: 560px) {
    margin-left: calc(-1 * var(--groupui-spacing-4));
    margin-right: calc(-1 * var(--groupui-spacing-4));
  }
`;

export default StyledGroupuiRow;
