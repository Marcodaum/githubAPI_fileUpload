import { GroupuiGridCol } from '@group-ui/group-ui-react';
import styled from 'styled-components';

const StyledGridCol = styled(GroupuiGridCol)`
    padding-bottom: 20px;
`;

export default StyledGridCol;
