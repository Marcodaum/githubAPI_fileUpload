import styled from 'styled-components';

interface BoardsGridProps {
    gridTemplate?: string[],
    marginTop?: number,
    marginRight?: number | 'auto',
    marginBottom?: number,
    marginLeft?: number | 'auto',
}

const groupuiSpacing = (spacing: number | string | undefined) => {
  if (!spacing) return 0;
  if (spacing === 'auto') return 'auto';
  if (typeof spacing === 'number' && spacing > 0) return `var(--groupui-spacing-${spacing})`;
  return '0';
};

const createGridColumns = (columnSizes: string[]) => columnSizes.reduce((cur, acc) => `${cur} ${acc}`, '');

const BoardsGrid = styled.div<BoardsGridProps>`
  display: grid;
  grid-template-columns: ${({ gridTemplate }) => createGridColumns(gridTemplate || ['auto', '0.8fr', '1fr', 'auto'])};
  align-items: center;
  margin: ${(props) => `
    ${groupuiSpacing(props.marginTop)} 
    ${groupuiSpacing(props.marginRight)} 
    ${groupuiSpacing(props.marginBottom)} 
    ${groupuiSpacing(props.marginLeft)}
  `};
`;

export default BoardsGrid;
