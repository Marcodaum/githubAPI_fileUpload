import styled from 'styled-components';
import { GroupuiHeadline, GroupuiIcon, GroupuiText } from '@group-ui/group-ui-react';

const WhiteHeadline = styled(GroupuiHeadline)`
  color: var(--groupui-vwag-color-white);
`;

const WhiteIcon = styled(GroupuiIcon)`
  color: var(--groupui-vwag-color-white);
`;

const White700Text = styled(GroupuiText)`
  font-weight: bold;
  color: var(--groupui-vwag-color-white);
`;

export { WhiteHeadline, WhiteIcon, White700Text };
