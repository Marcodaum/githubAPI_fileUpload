import React, { FC } from 'react';
import styled from 'styled-components';

interface OvalProps {
    marginRight?: number,
    marginLeft?: number,
}

const groupuiSpacing = (spacing: number | string | undefined) => {
  if (!spacing) return 0;
  if (spacing === 'auto') return 'auto';
  if (typeof spacing === 'number' && spacing > 0) return `var(--groupui-spacing-${spacing})`;
  return '0';
};

const Svg = styled.svg<OvalProps>` 
  width: 40px; 
  height: 40px;
    margin: ${(props) => `
    0
    ${groupuiSpacing(props.marginRight)} 
    0 
    ${groupuiSpacing(props.marginLeft)}
  `};
`;

export const Oval: FC<OvalProps> = ({
  marginLeft, marginRight,
}) => (
  <Svg
    viewBox="0 0 40 40"
    marginLeft={marginLeft}
    marginRight={marginRight}
  >
    <circle cx="20" cy="20" r="19" stroke="black" strokeWidth="1" fill="transparent" />
  </Svg>
);

Oval.defaultProps = {
  marginLeft: 0,
  marginRight: 0,
};

export default Oval;
