import { Control } from 'react-hook-form';
import React, { FC } from 'react';
import TextInput from '../form/text-input';
import { toOrdinal } from '../../utils/numbers';
import { Grey1000Headline } from '../styled/grey-text';
import Container from '../styled/container';

interface BoardCategoryFieldsProps {
  control: Control<any>,
  index: number,
}

const BoardCategoryFields: FC<BoardCategoryFieldsProps> = ({ control, index }) => {
  const ordinalIndex = toOrdinal(index + 1);
  return (
    <Container marginTop={index > 0 ? 7 : undefined}>
      <Grey1000Headline heading="h6">{`${ordinalIndex} Category`}</Grey1000Headline>
      <TextInput
        name={`categories.${index}.name`}
        control={control}
        placeholder={`Name of ${ordinalIndex} category`}
        label="Name"
        required
      />
      <TextInput
        name={`categories.${index}.description`}
        control={control}
        placeholder={`Description of ${ordinalIndex} category`}
        label="Description"
        required
      />
    </Container>
  );
};

export default BoardCategoryFields;
