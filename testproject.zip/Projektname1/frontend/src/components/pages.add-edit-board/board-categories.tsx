import { Control, useFieldArray } from 'react-hook-form';
import React, { FC } from 'react';
import BoardCategoryFields from './board-category-fields';

interface BoardCategoriesProps {
  control: Control<any>,
}

const BoardCategories: FC<BoardCategoriesProps> = ({ control }) => {
  const { fields } = useFieldArray({
    control,
    name: 'categories',
  });

  return (
    <>
      {fields.map((field, index) => (
        <BoardCategoryFields key={field.id} control={control} index={index} />
      ))}
    </>
  );
};

export default BoardCategories;
