import { GroupuiButton } from '@group-ui/group-ui-react';
import React, { FC, MouseEvent } from 'react';

export interface BoardActionButtonProps {
  onClick: (event: MouseEvent) => void,
  icon?: string,
  variant?: string,
  children: React.ReactNode,
}

const BoardActionButton: FC<BoardActionButtonProps> = ({ onClick, icon, variant, children }) => (
  <GroupuiButton
    type="button"
    role="button"
    size="s"
    variant={variant}
    icon={icon}
    onClick={(event) => {
      event.stopPropagation();
      onClick(event);
    }}
  >
    {children}
  </GroupuiButton>
);

BoardActionButton.defaultProps = {
  variant: 'primary',
  icon: undefined,
};

export default BoardActionButton;
