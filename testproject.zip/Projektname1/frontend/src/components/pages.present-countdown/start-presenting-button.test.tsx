import React from 'react';
import * as Router from 'react-router';
import { fireEvent } from '@testing-library/react';
import { render, screen } from '../../test/utils';

import StartPresentingButton from './start-presenting-button';
import Category from '../../models/category';

describe('start presenting button', () => {
  it('should show the correct text', () => {
    render(
      <StartPresentingButton category={{
        id: 'A_CATEGORY_ID',
        name: 'A_CATEGORY_NAME',
        description: 'A_CATEGORY_DESCRIPTION',
      }}
      />,
    );

    expect(screen.getByText('Start presenting')).toBeVisible();
  });

  it('should navigate to the given category on click', () => {
    const mockNavigateFunc = jest.fn();
    const givenCategory: Category = {
      id: 'A_CATEGORY_ID',
      name: 'A_CATEGORY_NAME',
      description: 'A_CATEGORY_DESCRIPTION',
    };
    jest.spyOn(Router, 'useNavigate').mockImplementation(() => mockNavigateFunc);

    render(
      <StartPresentingButton category={givenCategory} />,
    );

    fireEvent.click(screen.getByText('Start presenting'));

    expect(mockNavigateFunc).toHaveBeenCalledTimes(1);
    expect(mockNavigateFunc).toHaveBeenCalledWith(`/present/${givenCategory.id}`);
  });
});
