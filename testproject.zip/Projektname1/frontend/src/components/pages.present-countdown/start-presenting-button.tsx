import React, { FC, ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import { GroupuiButton } from '@group-ui/group-ui-react';
import Category from '../../models/category';

interface InputProps {
  category: Category,
}

const StartPresentingButton: FC<InputProps> = ({ category }): ReactElement => {
  const navigate = useNavigate();
  const { id } = category;

  return (
    <GroupuiButton variant="primary" onClick={() => navigate(`/present/${id}`)}>
      Start presenting
    </GroupuiButton>
  );
};

export default StartPresentingButton;
