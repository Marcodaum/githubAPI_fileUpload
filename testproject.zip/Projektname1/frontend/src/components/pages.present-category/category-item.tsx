import React, { FC, ReactElement } from 'react';
import {
  GroupuiButton, GroupuiDivider, GroupuiHeadline, GroupuiTag, GroupuiText,
} from '@group-ui/group-ui-react';
import BoardItemModel from '../../models/board-item';
import Container from '../styled/container';

interface CategoryItemProps {
  item: BoardItemModel
  isLast: boolean
}

const CategoryItem: FC<CategoryItemProps> = ({ item, isLast }): ReactElement => (
  <>
    <Container marginBottom={3} marginTop={10}>
      <GroupuiHeadline heading="h3">
        {item.title}
      </GroupuiHeadline>
    </Container>
    <Container marginBottom={7}>
      <GroupuiTag variant="secondary">
        {item.author}
      </GroupuiTag>
    </Container>
    <Container marginBottom={9}>
      <GroupuiText>
        {item.description}
      </GroupuiText>
    </Container>
    {item.link && (
    <Container marginBottom={10}>
      <GroupuiButton
        type="button"
        role="button"
        icon="arrow-right-16"
        icon-position="right"
        size="s"
        url={item.link}
        target="blank"
      >
        See more
      </GroupuiButton>
    </Container>
    )}
    {!isLast && <GroupuiDivider />}
  </>
);

export default CategoryItem;
