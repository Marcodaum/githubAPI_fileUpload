import React, { FC, PropsWithChildren, useContext } from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import {
  cleanup, fireEvent, render, screen, within,
} from './test/utils';
import App from './App';
import { PageProps as BoardsPageProps } from './pages/boards';
import { BoardIdContext } from './hooks/contexts/use-board-id-context';
import { StandupContext } from './hooks/contexts/use-standup-context';
import { NotificationContext } from './hooks/contexts/use-notification-context';
import NotificationType from './models/notification-type';

jest.mock('./components/layout/error-boundary', () => ({ children }: PropsWithChildren<any>) => (
  <div data-testid="error-boundary">{children}</div>
));

const MockNotificationConsumer: FC<PropsWithChildren<any>> = ({ children }) => {
  const { setNotification } = useContext(NotificationContext);
  return (
    <>
      <button type="button" onClick={() => setNotification(NotificationType.Error, 'mock-error-message')}>trigger-error</button>
      <button type="button" onClick={() => setNotification(NotificationType.Success, 'mock-success-message')}>trigger-success</button>
      <div>{children}</div>
    </>
  );
};
const MockBoardIdConsumer: FC<PropsWithChildren<any>> = ({ children }) => {
  const boardId = useContext(BoardIdContext);
  return (
    <>
      <p>{`board-id: ${boardId}`}</p>
      <div>{children}</div>
    </>
  );
};
const MockStandupConsumer: FC<PropsWithChildren<any>> = ({ children }) => {
  const standup = useContext(StandupContext);
  return (
    <>
      <p>{`board-name: ${standup.board.name}`}</p>
      <div>{children}</div>
    </>
  );
};

const MockPages = {
  Default: ({ children }: PropsWithChildren) => (
    <MockNotificationConsumer>
      {children}
    </MockNotificationConsumer>
  ),
  Board: ({ children }: PropsWithChildren) => (
    <MockNotificationConsumer>
      <MockBoardIdConsumer>
        {children}
      </MockBoardIdConsumer>
    </MockNotificationConsumer>
  ),
  Present: ({ children }: PropsWithChildren) => (
    <MockNotificationConsumer>
      <MockBoardIdConsumer>
        <MockStandupConsumer>
          {children}
        </MockStandupConsumer>
      </MockBoardIdConsumer>
    </MockNotificationConsumer>
  ),
};

jest.mock('./pages/boards', () => ({ onSelect }: BoardsPageProps) => (
  <MockPages.Default>
    <p>mock-boards-page</p>
    <button type="button" onClick={() => onSelect('other-board')}>other-board</button>
  </MockPages.Default>
));
jest.mock('./pages/add-board', () => () => <MockPages.Default>mock-add-board-page</MockPages.Default>);
jest.mock('./pages/board', () => () => <MockPages.Board>mock-board-page</MockPages.Board>);
jest.mock('./pages/add-item', () => () => <MockPages.Board>mock-add-item-page</MockPages.Board>);
jest.mock('./pages/edit-item', () => () => <MockPages.Board>mock-edit-item-page</MockPages.Board>);
jest.mock('./pages/present/countdown', () => () => <MockPages.Present>mock-present-countdown-page</MockPages.Present>);
jest.mock('./pages/present/category', () => () => <MockPages.Present>mock-present-category-page</MockPages.Present>);

const server = setupServer();

describe('App', () => {
  beforeAll(() => server.listen());
  afterAll(() => server.close());
  afterEach(() => {
    server.resetHandlers();
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value: '',
    });
  });

  it.each`
    name            | mockContent               | route
    ${'boards'}     | ${'mock-boards-page'}     | ${'/boards'}
    ${'add board'}  | ${'mock-add-board-page'}  | ${'/add-board'}
  `('renders the $name page at $route', ({ mockContent, route }) => {
    render(<App />, route);

    const mockErrorBoundary = screen.getByTestId('error-boundary');
    const container = within(mockErrorBoundary);
    expect(container.getByText(mockContent)).toBeVisible();

    expect(screen.getByText('Standup Boards')).toBeVisible();
  });

  it('displays the notifications', async () => {
    const { container } = render(<App />, '/boards');

    expect(screen.getByText('mock-boards-page')).toBeVisible();
    expect(screen.queryByText('mock-error-message')).not.toBeInTheDocument();
    let notificationElement = container.querySelector('groupui-notification');
    expect(notificationElement).toBeNull();

    fireEvent.click(screen.getByText('trigger-error'));

    expect(await screen.findByText('mock-error-message')).toBeVisible();
    expect(screen.queryByText('mock-success-message')).not.toBeInTheDocument();
    notificationElement = container.querySelector('groupui-notification');
    expect(notificationElement).toHaveAttribute('severity', 'danger');

    fireEvent.click(screen.getByText('trigger-success'));

    expect(await screen.findByText('mock-success-message')).toBeVisible();
    expect(screen.queryByText('mock-error-message')).not.toBeInTheDocument();
    notificationElement = container.querySelector('groupui-notification');
    expect(notificationElement).toHaveAttribute('severity', 'success');

    fireEvent(notificationElement!, new Event('groupuiClose'));

    expect(screen.queryByText('mock-success-message')).not.toBeInTheDocument();
  });

  it.each([
    '/',
    '/add-item',
    '/edit-item/item-id',
    '/present',
    '/present/category',
  ])('renders the boards page when the cookie is NOT set for %s', (route) => {
    render(<App />, route);

    expect(screen.getByText('mock-boards-page')).toBeVisible();
  });

  it.each`
    name                    | mockContent                       | route
    ${'board'}              | ${'mock-board-page'}              | ${'/'}
    ${'add item'}           | ${'mock-add-item-page'}           | ${'/add-item'}
    ${'edit item'}          | ${'mock-edit-item-page'}          | ${'/edit-item/item-id'}
  `('renders the $name page for $route with the board ID context', async ({ mockContent, route }) => {
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value: 'board=lisbon',
    });

    render(<App />, route);

    const mockErrorBoundary = screen.getByTestId('error-boundary');
    const container = within(mockErrorBoundary);

    expect(await container.findByText(mockContent)).toBeVisible();

    expect(container.queryByText('mock-boards-page')).not.toBeInTheDocument();
    expect(container.getByText('board-id: lisbon')).toBeVisible();

    expect(screen.getByText('Standup Boards')).toBeVisible();
  });

  it('changes the board', async () => {
    render(<App />, '/');
    expect(screen.queryByText('board-id: other-board')).not.toBeInTheDocument();
    cleanup();

    render(<App />, '/boards');
    fireEvent.click(screen.getByText('other-board'));
    cleanup();

    render(<App />, '/');
    expect(screen.getByText('board-id: other-board')).toBeVisible();
  });

  it.each`
    name            | mockContent                       | route
    ${'countdown'}  | ${'mock-present-countdown-page'}  | ${'/present'}
    ${'category 1'} | ${'mock-present-category-page'}   | ${'/present/category-1'}
    ${'category 2'} | ${'mock-present-category-page'}   | ${'/present/category-2'}
  `('renders the present $name page for $route with the standup context', async ({ mockContent, route }) => {
    jest.useFakeTimers({ now: new Date(2022, 3, 25) });

    server.use(
      rest.get(`${process.env.API_URL}/standups`, (req, res, ctx) => {
        if (req.url.searchParams.get('board_id') === 'lisbon' && req.url.searchParams.get('standup_date') === '2022-04-25') {
          return res(ctx.json({ board: { id: 'lisbon', name: 'SDC Lisbon' } }));
        }
        return res(ctx.status(400));
      }),
    );

    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value: 'board=lisbon',
    });

    render(<App />, route);

    const mockErrorBoundary = screen.getByTestId('error-boundary');
    const container = within(mockErrorBoundary);

    expect(await container.findByText(mockContent)).toBeVisible();
    expect(container.queryByText('mock-boards-page')).not.toBeInTheDocument();
    expect(container.getByText('board-id: lisbon')).toBeVisible();
    expect(container.getByText('board-name: SDC Lisbon')).toBeVisible();

    expect(screen.queryByText('Standup Boards')).not.toBeInTheDocument();
  });
});
