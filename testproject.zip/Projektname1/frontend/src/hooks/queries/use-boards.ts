import { QueryKey, useQuery } from 'react-query';
import apiFetch from '../../utils/api-fetch';
import Board from '../../models/board';

export interface BoardsList {
  boards: Board[],
}

export interface BoardsQuery {
  boardsList: BoardsList;
  hasLoaded: boolean;
}

const useBoards = (): BoardsQuery => {
  const { data, isFetched } = useQuery<BoardsList, Error, BoardsList, QueryKey>('boards', () => (
    apiFetch('boards').then((response) => response.json())
  ));
  return { boardsList: data!, hasLoaded: isFetched };
};

export default useBoards;
