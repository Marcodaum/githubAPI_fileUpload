import { QueryKey, useQuery } from 'react-query';
import apiFetch from '../../utils/api-fetch';
import Standup from '../../models/standup';

const useStandup = (boardId: string, date: string) => (
  useQuery<Standup, Error, Standup, QueryKey>(
    ['standup', boardId, date],
    () => (
      apiFetch(`standups?board_id=${boardId}&standup_date=${date}`).then((response) => response.json())
    ),
  )
);

export default useStandup;
