import { QueryKey, useQuery } from 'react-query';
import apiFetch from '../../utils/api-fetch';
import { today } from '../../utils/dates';
import Board from '../../models/board';

export interface BoardQuery {
  board: Board;
  hasLoaded: boolean;
}

const useBoard = (boardId: string): BoardQuery => {
  const { data, isFetched } = useQuery<Board, Error, Board, QueryKey>(
    ['board', boardId],
    () => (
      apiFetch(`boards/${boardId}?from_date=${today()}`).then((response) => response.json())
    ),
    {
      initialData: {
        id: '',
        name: '',
        startTime: '',
        timezone: '',
        categories: [],
        items: [],
      },
    },
  );
  return { board: data!, hasLoaded: isFetched };
};

export default useBoard;
