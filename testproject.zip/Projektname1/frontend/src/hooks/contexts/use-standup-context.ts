import React, { useContext } from 'react';
import Standup from '../../models/standup';

const standup: Standup = {
  board: {
    id: '',
    name: '',
    startTime: '',
    timezone: '',
    categories: [],
    items: [],
  },
  items: [],
};

export const StandupContext = React.createContext<Standup>(standup);

const useStandupContext = () => useContext(StandupContext);

export default useStandupContext;
