import React, { useContext } from 'react';
import NotificationType from '../../models/notification-type';

export interface NotificationContextType {
  setNotification: (type: NotificationType, message: string) => void
}
export const NotificationContext = React.createContext<NotificationContextType>({
  setNotification: () => {},
});

const useNotificationContext = () => useContext(NotificationContext);

export default useNotificationContext;
