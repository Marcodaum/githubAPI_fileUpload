import React, { useContext } from 'react';

export const BoardIdContext = React.createContext<string>('');

const useBoardIdContext = () => useContext(BoardIdContext);

export default useBoardIdContext;
