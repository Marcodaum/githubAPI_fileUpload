module.exports = async () => {
  process.env.TZ = 'Europe/Lisbon';
};
