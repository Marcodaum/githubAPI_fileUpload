import React from 'react';
import { fireEvent, render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';

const customRender = (ui: React.ReactElement, route: string = '/') => render(
  <QueryClientProvider client={new QueryClient()}>
    <MemoryRouter initialEntries={[route]}>
      {ui}
    </MemoryRouter>
  </QueryClientProvider>,
);

const groupuiChange = (element: Document | Element | Window | Node, value: string) => {
  // @ts-ignore
  // eslint-disable-next-line no-param-reassign
  element.value = value;
  fireEvent(element, new Event('groupuiChange'));
};

export * from '@testing-library/react';
export {
  groupuiChange,
  customRender as render,
};
