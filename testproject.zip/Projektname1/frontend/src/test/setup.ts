import '@testing-library/jest-dom';

afterEach(() => {
  jest.clearAllMocks();
  jest.useRealTimers();
  // @ts-ignore
  // eslint-disable-next-line no-console
  console.error.mockRestore();
});

beforeEach(() => {
  jest.spyOn(console, 'error');
  process.env.API_URL = 'http://localhost:9999';
});
