import Board from './board';
import BoardItem from './board-item';

interface Standup {
  board: Board
  items: BoardItem[],
}

export default Standup;
