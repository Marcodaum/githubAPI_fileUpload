interface BoardItem {
    id: string,
    boardId: string,
    category: string,
    startDate: string,
    endDate: string,
    title: string,
    author: string,
    description: string,
    link: string,
    images: string [],
}

export default BoardItem;
