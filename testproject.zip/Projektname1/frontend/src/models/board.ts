import Category from './category';
import BoardItem from './board-item';

interface Board {
  id: string,
  name: string,
  startTime: string,
  timezone: string,
  categories: Category[]
  items: BoardItem[]
}

export default Board;
