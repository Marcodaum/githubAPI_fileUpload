enum NotificationType {
  Default = 'default',
  Error = 'danger',
  Success = 'success',
}

export default NotificationType;
